# Migrações

As migrações já foram aplicadas no projeto Supabase pelo painel.
Este diretório existe para versionar alterações futuras.

Padrão de nome: `AAAAMMDD_descricao.sql`.

Ordem já aplicada:

1. `esquema_inicial_pdv` — produtos, clientes, pedidos, itens, campanhas, config
2. `cardapio_inicial_e_views` — dados iniciais e visões
3. `perfis_e_permissoes` — papéis, investimentos, custos separados
4. `rpc_pedidos_e_rls_final` — função de registro e políticas de acesso
5. `erp_caixa_estoque_financeiro` — caixa, insumos, despesas, equipe
6. `erp_fidelidade_marketing_fiscal` — fidelidade, promoções, WhatsApp, fiscal
7. `usuarios_fixos_saborido_lanchonete` — contas fixas e bloqueio
8. `rpc_pedido_com_caixa_e_desconto` — pedido vinculado ao caixa
9. `rpcs_financeiro` — resumos de período e 12 meses
10. `rpc_fidelidade_resgate` — resgate validado no servidor
