# Estrutura do banco

Projeto Supabase: `trailer-pdv` (região São Paulo).

## Tabelas

| Tabela | Para que serve | Quem lê |
|---|---|---|
| `perfis` | Usuários e papel (admin / operador) | próprio + admin |
| `produtos` | Cardápio e preço de venda | todos |
| `produto_custos` | Custo do insumo por produto | admin |
| `pedidos` | Vendas, pagamento, desconto, caixa | admin |
| `pedido_itens` | Itens de cada pedido | admin |
| `vw_fila` | Visão da fila sem dados financeiros | todos |
| `clientes` | Base de clientes e fidelidade | admin |
| `caixas` | Abertura e fechamento de turno | todos |
| `caixa_movimentos` | Sangria e suprimento | todos |
| `insumos` | Estoque, validade e mínimo | todos |
| `insumo_movimentos` | Entrada, baixa, perda e ajuste | todos |
| `fornecedores` | Fornecedores e contatos | admin |
| `despesas` | Contas a pagar e custo fixo | admin |
| `maquininhas` | Taxas por modalidade | admin |
| `funcionarios` / `escalas` | Equipe, salário e escala | admin |
| `investimentos` | Compras por onda de prioridade | admin |
| `fidelidade_regras` / `fidelidade_cartoes` | Programa de fidelidade | leitura geral |
| `promocoes` | Promoções e vínculo com modelo | leitura geral |
| `wa_templates` / `wa_envios` | Modelos e histórico de campanhas | leitura geral |
| `documentos_fiscais` | NFC-e emitidas | admin |
| `metas` | Metas mensais | admin |
| `config` | Dados da loja e chave PIX | todos |

## Funções

- `registrar_pedido(jsonb)` — grava pedido, itens e cliente numa operação só,
  calculando o custo no servidor. É o único caminho de escrita do atendente.
- `marcar_status(uuid, texto)` — muda o pedido de produção para pronto/entregue.
- `resumo_caixa(uuid)` — totais do turno para o fechamento.
- `resumo_periodo(data, data)` — indicadores do financeiro.
- `resumo_12_meses()` — comparativo mensal.
- `resgatar_fidelidade(uuid)` — valida os carimbos antes de permitir o resgate.
- `eh_admin()` — usada pelas políticas de permissão.

## Gatilhos

- Novo usuário → cria perfil (primeiro vira admin).
- Terceiro usuário → bloqueado.
- Pedido gravado → atualiza estatísticas do cliente e carimba a fidelidade.
- Movimento de insumo → recalcula o estoque.
