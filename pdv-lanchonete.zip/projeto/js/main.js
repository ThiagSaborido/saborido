/* main.js — Atalhos, relogio e inicializacao
   Projeto: Sistema PDV/ERP Lanchonete */

/* ============ teclado ============ */
$("#busca").oninput=grid;
$("#busca").onkeydown=e=>{if(e.key==="Enter"){const l=filtrados();if(l.length){add(l[0].id);$("#busca").value="";grid()}}};
document.addEventListener("keydown",e=>{
  if($("#login").style.display!=="none")return;
  if(e.key==="F2"){e.preventDefault();$("#busca").focus();$("#busca").select()}
  if(e.key==="F3"){e.preventDefault();$("#cliente").focus()}
  if(e.key==="F8"){e.preventDefault();if(!$("#btnPagar").disabled)pagar()}
  if(e.altKey&&e.key>="1"&&e.key<="9"){const p=filtrados()[+e.key-1];if(p){e.preventDefault();add(p.id)}}
});
setInterval(()=>{$("#relogio").textContent=new Date().toLocaleTimeString("pt-BR",{hour:"2-digit",minute:"2-digit"})},1000);
sinal();
