/* cardapio.js — Envio do cardapio
   Projeto: Sistema PDV/ERP Lanchonete */

/* ============ cardápio compartilhável ============ */
function textoCardapio(){
  const cats=[...new Set(produtos.map(p=>p.categoria))];
  let t=`*${(loja.nome||"Cardápio").toUpperCase()}*\n`;
  if(loja.telefone)t+=`${loja.telefone}\n`;
  cats.forEach(c=>{t+=`\n*${c.toUpperCase()}*\n`;
    produtos.filter(p=>p.categoria===c).forEach(p=>{t+=`• ${p.nome} — ${money(p.preco)}\n`})});
  if(pix.chave)t+=`\n_Aceitamos PIX, dinheiro e cartão._`;
  return t;
}
function renderCardapio(){
  const t=textoCardapio();
  $("#cardapio").innerHTML=`<h2>Enviar cardápio</h2>
  <p class="sub">Cardápio gerado a partir dos preços atuais. Envie direto para um cliente ou copie e cole onde quiser.</p>
  <div class="dois">
    <div class="bloco"><h3>Prévia</h3>
      <div style="white-space:pre-wrap;background:#F8FAFC;border:1px solid var(--line);border-radius:var(--rs);
        padding:16px;font-size:13.5px;max-height:52vh;overflow-y:auto">${esc(t)}</div>
      <div class="toolbar" style="margin:14px 0 0">
        <button class="btn btn-go" id="cpC">Copiar cardápio</button>
        <button class="btn btn-out" id="waC">Abrir WhatsApp</button></div></div>
    <div class="bloco"><h3>Enviar para um cliente</h3>
      <div class="campo"><label>Buscar cliente cadastrado</label><input id="bcc" placeholder="Nome ou telefone" autocomplete="off"></div>
      <div id="listaCC" style="max-height:38vh;overflow-y:auto"></div>
      <div class="campo" style="margin-top:14px"><label>Ou digite um número com DDD</label>
        <div class="linha"><input id="numAv" inputmode="numeric" placeholder="22999998888">
          <button class="btn btn-out" id="envNum">Enviar</button></div></div></div>
  </div>`;
  $("#cpC").onclick=()=>copiar(t,"Cardápio copiado");
  $("#waC").onclick=()=>window.open(`https://wa.me/?text=${encodeURIComponent(t)}`,"_blank");
  $("#envNum").onclick=()=>{const n=dig($("#numAv").value);
    if(n.length<10){toast("Número inválido");return}
    window.open(`https://wa.me/55${n}?text=${encodeURIComponent(t)}`,"_blank")};
  const pinta=()=>{const q=($("#bcc").value||"").toLowerCase();
    const l=clientes.filter(c=>c.telefone&&(c.nome.toLowerCase().includes(q)||c.telefone.includes(q))).slice(0,25);
    $("#listaCC").innerHTML=l.length?l.map(c=>`<div class="rank" style="cursor:pointer" data-env="${c.telefone}">
      <span><b>${esc(c.nome)}</b> <span class="sub">${esc(c.telefone)}</span></span>
      <span class="sub">enviar</span></div>`).join(""):`<p class="sub">Nenhum cliente com telefone.</p>`;
    $$("[data-env]").forEach(e=>e.onclick=()=>window.open(`https://wa.me/55${e.dataset.env}?text=${encodeURIComponent(t)}`,"_blank"))};
  $("#bcc").oninput=pinta;pinta();
}
