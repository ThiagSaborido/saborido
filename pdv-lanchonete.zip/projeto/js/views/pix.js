/* pix.js — Chave PIX com copiar
   Projeto: Sistema PDV/ERP Lanchonete */

/* ============ PIX ============ */
function renderPix(){
  const msg=(pix.mensagem||"").replace("{chave}",pix.chave||"—").replace("{titular}",pix.titular||"");
  $("#pix").innerHTML=`<h2>Chave PIX</h2><p class="sub">Copie a mensagem pronta e cole na conversa do cliente.</p>
  ${pix.chave?`<div class="dois">
    <div class="bloco"><h3>Mensagem pronta</h3>
      <div style="white-space:pre-wrap;background:#F7F9FB;border:1px solid var(--line);border-radius:6px;padding:14px;font-size:14px">${esc(msg)}</div>
      <div class="toolbar" style="margin:14px 0 0">
        <button class="btn btn-go" id="copMsg">Copiar mensagem completa</button>
        <button class="btn btn-out" id="copCh">Copiar só a chave</button></div></div>
    <div class="bloco"><h3>Dados</h3>
      <div class="rank"><span>Chave</span><span class="num">${esc(pix.chave)}</span></div>
      <div class="rank"><span>Titular</span><span>${esc(pix.titular||"—")}</span></div>
      <div class="rank"><span>Banco</span><span>${esc(pix.banco||"—")}</span></div>
      ${adm()?`<p class="sub" style="margin-top:12px">Para alterar, vá em Configurações.</p>`:""}</div></div>`
    :`<div class="bloco"><p class="sub">Nenhuma chave PIX cadastrada${adm()?". Cadastre em Configurações.":". Peça ao administrador para cadastrar."}</p></div>`}`;
  if(pix.chave){
    $("#copMsg").onclick=()=>copiar(msg,"Mensagem copiada");
    $("#copCh").onclick=()=>copiar(pix.chave,"Chave copiada")}
}
function copiar(t,m){
  navigator.clipboard.writeText(t).then(()=>toast(m)).catch(()=>{
    const a=document.createElement("textarea");a.value=t;document.body.appendChild(a);a.select();
    document.execCommand("copy");a.remove();toast(m)})}
