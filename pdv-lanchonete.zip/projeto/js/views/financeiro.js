/* financeiro.js — Indicadores e graficos
   Projeto: Sistema PDV/ERP Lanchonete */

/* ============ financeiro ============ */
async function renderFinanceiro(){
  const [ini,fim]=intervalo();
  const {data:r}=await sb.rpc("resumo_periodo",{p_ini:ini,p_fim:fim});
  const {data:m12}=await sb.rpc("resumo_12_meses");
  const bruto=+r.bruto,cmv=+r.cmv,desp=+r.despesas;
  const liq=bruto-cmv,lucro=liq-desp,tk=r.pedidos?bruto/r.pedidos:0;
  const mb=bruto?(1-cmv/bruto)*100:0,ml=bruto?lucro/bruto*100:0,mk=cmv?((bruto-cmv)/cmv)*100:0;
  const f=r.formas||{},pega=k=>+(f[k]||0);
  const per=[["hoje","Hoje"],["mes","Este mês"],["passado","Mês passado"],["30","Últimos 30 dias"]];
  const kp=(l,v,d)=>`<div class="kpi ${d?"dest":""}"><div class="lb">${l}</div><div class="vl num">${v}</div></div>`;
  const maxM=Math.max(1,...(m12||[]).map(x=>+x.bruto));
  const horas=Object.entries(r.horas||{}).sort();
  const maxH=Math.max(1,...horas.map(([,v])=>+v));

  $("#financeiro").innerHTML=`<h2>Financeiro</h2>
  <p class="sub">Período de ${new Date(ini+"T12:00").toLocaleDateString("pt-BR")} a ${new Date(fim+"T12:00").toLocaleDateString("pt-BR")}.</p>
  <div class="toolbar">${per.map(([k,t])=>`<button class="btn ${periodo===k?"btn-pri":"btn-out"} sm" data-per="${k}">${t}</button>`).join("")}</div>
  <div class="kpis">
    ${kp("Faturamento bruto",money(bruto),1)}${kp("Lucro líquido",money(lucro),1)}
    ${kp("Pedidos",r.pedidos)}${kp("Ticket médio",money(tk))}
    ${kp("Custo dos produtos",money(cmv))}${kp("Faturamento líquido",money(liq))}
    ${kp("Total de despesas pagas",money(desp))}${kp("Descontos concedidos",money(r.desconto))}
    ${kp("Margem bruta",mb.toFixed(1)+"%")}${kp("Margem líquida",ml.toFixed(1)+"%")}
    ${kp("Markup",mk.toFixed(1)+"%")}${kp("Estoque valorizado",money(r.estoque))}
    ${kp("Contas em aberto",money(r.a_pagar))}${kp("Produtos cadastrados",r.itens_cad)}
    ${kp("Clientes cadastrados",r.clientes)}
  </div>
  <div class="dois">
    <div class="bloco"><h3>Vendas por forma de pagamento</h3>
      ${["Dinheiro","PIX","Debito","Credito"].map(k=>`<div class="rank"><span>${k==="Debito"?"Cartão débito":k==="Credito"?"Cartão crédito":k}</span>
        <span class="num">${money(pega(k))} <span class="sub">${bruto?Math.round(pega(k)/bruto*100):0}%</span></span></div>`).join("")}</div>
    <div class="bloco"><h3>Produtos mais vendidos</h3>
      ${(r.produtos||[]).length?(r.produtos||[]).map(p=>`<div class="rank"><span>${esc(p.nome)}</span>
        <span class="num">${p.qtd} un · ${money(p.valor)}</span></div>`).join(""):`<p class="sub">Sem vendas no período.</p>`}</div>
  </div>
  <div class="bloco" style="margin-top:16px"><h3>Vendas por horário</h3>
    ${horas.length?`<div style="display:flex;gap:4px;align-items:flex-end;height:130px;margin-top:8px">
      ${horas.map(([h,v])=>`<div style="flex:1;text-align:center">
        <div style="background:var(--navy);border-radius:3px 3px 0 0;height:${Math.round(+v/maxH*100)}px" title="${money(v)}"></div>
        <div class="sub" style="font-size:11px;margin-top:4px">${h}h</div></div>`).join("")}</div>`
      :`<p class="sub">Sem vendas no período.</p>`}</div>
  <div class="bloco" style="margin-top:16px"><h3>Comparativo dos últimos 12 meses</h3>
    ${(m12||[]).length?`<div style="display:flex;gap:6px;align-items:flex-end;height:150px;margin:10px 0">
      ${m12.map(x=>`<div style="flex:1;text-align:center">
        <div class="sub" style="font-size:11px">${money(x.bruto).replace("R$ ","")}</div>
        <div style="background:var(--green);border-radius:3px 3px 0 0;height:${Math.round(+x.bruto/maxM*110)}px"></div>
        <div class="sub" style="font-size:11px;margin-top:4px">${x.mes.slice(5)}/${x.mes.slice(2,4)}</div></div>`).join("")}</div>`
      :`<p class="sub">Ainda não há histórico suficiente.</p>`}</div>`;
  $$("[data-per]").forEach(b=>b.onclick=()=>{periodo=b.dataset.per;renderFinanceiro()});
}
