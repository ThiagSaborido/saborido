/* fornecedores.js — Fornecedores
   Projeto: Sistema PDV/ERP Lanchonete */

/* ============ fornecedores ============ */
function renderFornecedores(){
  $("#fornecedores").innerHTML=`<h2>Fornecedores</h2>
  <p class="sub">Quem te abastece, com contato e prazo. Use o botão para abrir o WhatsApp direto.</p>
  <div class="toolbar"><button class="btn btn-pri sm" id="af">Adicionar fornecedor</button></div>
  <div class="tabela"><table><thead><tr><th style="width:22%">Nome</th><th>Contato</th><th style="width:140px">Telefone</th>
    <th>Categoria</th><th style="width:120px">Prazo</th><th style="width:150px"></th></tr></thead><tbody>
    ${fornecedores.length?fornecedores.map(f=>`<tr data-id="${f.id}">
      <td><input data-f="nome" value="${esc(f.nome)}"></td>
      <td><input data-f="contato" value="${esc(f.contato||"")}"></td>
      <td><input data-f="telefone" value="${esc(f.telefone||"")}"></td>
      <td><input data-f="categoria" value="${esc(f.categoria||"")}"></td>
      <td><input data-f="prazo_entrega" value="${esc(f.prazo_entrega||"")}"></td>
      <td>${f.telefone?`<button class="btn btn-out sm" data-wa="${dig(f.telefone)}">WhatsApp</button>`:""}
          <button class="btn btn-del sm" data-df="${f.id}">Excluir</button></td></tr>`).join("")
      :`<tr><td colspan="6" class="sub" style="padding:26px;text-align:center">Nenhum fornecedor cadastrado.</td></tr>`}
  </tbody></table></div>`;
  $("#af").onclick=async()=>{await sb.from("fornecedores").insert({nome:"Novo fornecedor"});
    await carregar("fornecedores","nome");renderFornecedores()};
  $$("#fornecedores input").forEach(el=>editar(el,"fornecedores"));
  $$("[data-wa]").forEach(b=>b.onclick=()=>window.open(`https://wa.me/55${b.dataset.wa}`,"_blank"));
  $$("[data-df]").forEach(b=>b.onclick=async()=>{if(!confirm("Excluir?"))return;
    await sb.from("fornecedores").delete().eq("id",b.dataset.df);await carregar("fornecedores","nome");renderFornecedores()});
}
