/* troco.js — Calculadora de troco
   Projeto: Sistema PDV/ERP Lanchonete */

/* ============ troco ============ */
function renderTroco(){
  $("#troco").innerHTML=`<h2>Calculadora de troco</h2>
  <p class="sub">Funciona nos dois sentidos: mostra o troco ou quanto ainda falta o cliente pagar.</p>
  <div class="bloco" style="max-width:460px">
    <div class="campo"><label>Valor total da compra</label><input id="t1" type="number" step="0.01" placeholder="Ex.: 34,00" autofocus></div>
    <div class="campo"><label>Valor pago pelo cliente</label><input id="t2" type="number" step="0.01" placeholder="Ex.: 30,00"></div>
    <div class="faixa" style="margin:0"><span id="tl">Resultado</span><b class="num" id="tv">R$ 0,00</b></div>
    <div class="toolbar" style="margin:14px 0 0"><button class="btn btn-out sm" id="tlimpa">Limpar</button></div>
  </div>`;
  const calc=()=>{const t=+$("#t1").value||0,p=+$("#t2").value||0,d=p-t;
    if(!t&&!p){$("#tl").textContent="Resultado";$("#tv").textContent="R$ 0,00";$("#tv").style.color="var(--navy)";return}
    if(d>=0){$("#tl").textContent="Troco para o cliente";$("#tv").textContent=money(d);$("#tv").style.color="var(--green)"}
    else{$("#tl").textContent="Falta o cliente pagar";$("#tv").textContent=money(-d);$("#tv").style.color="var(--red)"}};
  $("#t1").oninput=calc;$("#t2").oninput=calc;
  $("#tlimpa").onclick=()=>{$("#t1").value="";$("#t2").value="";calc();$("#t1").focus()};
}
