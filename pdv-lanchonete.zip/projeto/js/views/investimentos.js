/* investimentos.js — Investimentos por onda
   Projeto: Sistema PDV/ERP Lanchonete */

/* ============ investimentos ============ */
function renderInvest(){
  const tot=i=>+i.qtd * +i.valor_unitario,soma=l=>l.reduce((s,i)=>s+tot(i),0);
  const comp=invest.filter(i=>i.status==="comprado"),plan=invest.filter(i=>i.status==="planejado");
  const dep=soma(invest.filter(i=>i.depreciavel));
  const NOMES={1:"Onda 1 — sem isso não abre",2:"Onda 2 — comprar com o caixa das primeiras semanas",3:"Onda 3 — quando o volume pedir"};
  $("#investimentos").innerHTML=`<h2>Investimentos</h2>
  <p class="sub">Tudo que foi ou será comprado, organizado por prioridade de compra.</p>
  <div class="kpis">
    <div class="kpi dest"><div class="lb">Total previsto</div><div class="vl num">${money(soma(invest))}</div></div>
    <div class="kpi"><div class="lb">Já comprado</div><div class="vl num">${money(soma(comp))}</div></div>
    <div class="kpi"><div class="lb">Falta comprar</div><div class="vl num">${money(soma(plan))}</div></div>
    <div class="kpi"><div class="lb">Base depreciável</div><div class="vl num">${money(dep)}</div></div>
    <div class="kpi"><div class="lb">Depreciação mensal</div><div class="vl num">${money(dep/60)}</div></div>
  </div>
  <div class="toolbar"><button class="btn btn-pri sm" id="ain">Adicionar item</button></div>
  ${[1,2,3].map(o=>{const l=invest.filter(i=>i.onda===o);return `
    <h3 style="margin:18px 0 9px">${NOMES[o]} · ${money(soma(l))}</h3>
    <div class="tabela"><table><thead><tr><th style="width:26%">Item</th><th>Categoria</th><th style="width:70px">Qtd</th>
      <th style="width:110px">Unitário</th><th style="width:110px">Total</th><th style="width:120px">Prioridade</th>
      <th style="width:80px">Deprecia</th><th style="width:130px">Status</th><th style="width:80px"></th></tr></thead><tbody>
      ${l.length?l.map(i=>`<tr data-id="${i.id}">
        <td><input data-f="item" value="${esc(i.item)}"></td>
        <td><input data-f="categoria" value="${esc(i.categoria)}"></td>
        <td><input data-f="qtd" type="number" step="1" value="${+i.qtd}"></td>
        <td><input data-f="valor_unitario" type="number" step="0.01" value="${+i.valor_unitario}"></td>
        <td class="num"><b>${money(tot(i))}</b></td>
        <td><select data-f="prioridade">${["Essencial","Importante","Baixa"].map(p=>`<option ${p===i.prioridade?"selected":""}>${p}</option>`).join("")}</select></td>
        <td><input type="checkbox" data-f="depreciavel" ${i.depreciavel?"checked":""} style="width:auto"></td>
        <td><select data-f="status"><option value="planejado" ${i.status==="planejado"?"selected":""}>A comprar</option>
          <option value="comprado" ${i.status==="comprado"?"selected":""}>Comprado</option></select></td>
        <td><button class="btn btn-del sm" data-di="${i.id}">Excluir</button></td></tr>`).join("")
        :`<tr><td colspan="9" class="sub" style="padding:18px;text-align:center">Nada nesta onda.</td></tr>`}
    </tbody></table></div>`}).join("")}`;
  $("#ain").onclick=async()=>{await sb.from("investimentos").insert({item:"Novo item",onda:1,ordem:invest.length+1});
    await carregar("investimentos","ordem");renderInvest()};
  $$("#investimentos input[data-f],#investimentos select[data-f]").forEach(el=>el.onchange=async()=>{
    const id=el.closest("tr").dataset.id,f=el.dataset.f;
    const v=el.type==="checkbox"?el.checked:(["qtd","valor_unitario"].includes(f)?(+el.value||0):el.value);
    await salvarCampo("investimentos",id,f,v);await carregar("investimentos","ordem");renderInvest()});
  $$("[data-di]").forEach(b=>b.onclick=async()=>{if(!confirm("Excluir?"))return;
    await sb.from("investimentos").delete().eq("id",b.dataset.di);await carregar("investimentos","ordem");renderInvest()});
}
