/* fila.js — Fila de pedidos
   Projeto: Sistema PDV/ERP Lanchonete */

/* ============ fila ============ */
function pill(){const n=filaView.filter(p=>p.status==="producao").length+pend.length;
  const e=$("#pillFila");if(e){e.style.display=n?"":"none";e.textContent=n}sinal()}
function renderFila(){
  const loc=pend.filter(p=>p.data===hoje()).map(p=>({...p,status:"producao",local:true,
    itens:p.itens.map(i=>({nome:i.nome,qtd:i.qtd,obs:i.obs}))}));
  const t=[...loc,...filaView];
  const g={producao:["Em produção",t.filter(p=>p.status==="producao")],
           pronto:["Pronto — chamar",t.filter(p=>p.status==="pronto")],
           entregue:["Entregue",t.filter(p=>p.status==="entregue").slice(0,8)]};
  $("#fila").innerHTML=`<h2>Fila de pedidos</h2><p class="sub">Atualiza sozinho em todos os aparelhos.</p>
  <div class="colunas">`+Object.entries(g).map(([k,[tt,l]])=>`<div><h3 style="margin-bottom:10px;color:var(--ink2)">${tt} (${l.length})</h3>
   ${l.length?l.map(p=>`<div class="card ${k}">
    <div class="hd"><span class="nome">${esc(p.cliente_nome)}</span>
      <span class="sen num">${String(p.numero).padStart(3,"0")} · ${hora(p.criado_em)}</span></div>
    <ul>${(p.itens||[]).map(i=>`<li>${i.qtd}x ${esc(i.nome)}${i.obs?` <em>— ${esc(i.obs)}</em>`:""}</li>`).join("")}</ul>
    <div class="acts">${k==="producao"&&!p.local?`<button class="btn btn-go sm" data-st="${p.id}|pronto">Marcar pronto</button>`:""}
      ${k==="pronto"?`<button class="btn btn-go sm" data-st="${p.id}|entregue">Entregue</button>`:""}
      ${p.local?`<span class="sub" style="flex:1">aguardando envio</span>`:""}</div></div>`).join("")
    :`<p class="sub">Nada aqui.</p>`}</div>`).join("")+`</div>`;
  $$("[data-st]").forEach(b=>b.onclick=async()=>{const [id,st]=b.dataset.st.split("|");
    await sb.rpc("marcar_status",{p_id:id,p_status:st});await carregarFila();renderFila()});
}
