/* caixa.js — Abertura, sangria, suprimento e fechamento
   Projeto: Sistema PDV/ERP Lanchonete */

/* ============ caixa ============ */
async function renderCaixa(){
  if(!caixa){
    $("#caixa").innerHTML=`<div class="bloqueio"><div class="ic2"><svg><use href="#i-lock"/></svg></div>
      <h2>Nenhum caixa aberto</h2>
      <p class="sub" style="margin:8px 0 18px">Abra o caixa informando o dinheiro que está na gaveta agora.
        Sem caixa aberto o sistema não registra vendas.</p>
      <div class="bloco" style="text-align:left">
        <div class="campo"><label>Valor de abertura (troco inicial)</label>
          <input id="vab" type="number" step="0.01" placeholder="0,00" autofocus></div>
        <button class="btn btn-go" id="abrir" style="width:100%;padding:12px">Abrir caixa</button></div></div>`;
    $("#abrir").onclick=async()=>{
      const v=+$("#vab").value||0;
      const {error}=await sb.from("caixas").insert({aberto_por:perfil.id,valor_abertura:v});
      if(error){toast("Erro ao abrir caixa");return}
      await verCaixa();renderCaixa();toast("Caixa aberto")};
    return;
  }
  const {data:r}=await sb.rpc("resumo_caixa",{p_caixa:caixa.id});
  const {data:movs}=await sb.from("caixa_movimentos").select("*").eq("caixa_id",caixa.id).order("criado_em",{ascending:false});
  const f=r.formas||{},din=+(f.Dinheiro||0);
  const esperado=+r.abertura + din + +r.suprimentos - +r.sangrias;
  $("#caixa").innerHTML=`<h2>Caixa aberto</h2>
  <p class="sub">Aberto às ${hora(caixa.aberto_em)} com ${money(r.abertura)} na gaveta.</p>
  <div class="kpis">
    <div class="kpi dest"><div class="lb">Dinheiro esperado na gaveta</div><div class="vl num">${money(esperado)}</div></div>
    <div class="kpi"><div class="lb">Vendas do turno</div><div class="vl num">${money(r.total)}</div></div>
    <div class="kpi"><div class="lb">Pedidos</div><div class="vl num">${r.pedidos}</div></div>
    <div class="kpi"><div class="lb">Suprimentos</div><div class="vl num">${money(r.suprimentos)}</div></div>
    <div class="kpi"><div class="lb">Sangrias</div><div class="vl num">${money(r.sangrias)}</div></div>
  </div>
  <div class="dois">
    <div class="bloco"><h3>Recebido por forma de pagamento</h3>
      ${Object.keys(f).length?Object.entries(f).map(([k,v])=>`<div class="rank"><span>${esc(k)}</span><span class="num">${money(v)}</span></div>`).join(""):`<p class="sub">Nenhuma venda ainda.</p>`}</div>
    <div class="bloco"><h3>Movimentações do turno</h3>
      ${(movs||[]).length?movs.map(m=>`<div class="rank"><span>${m.tipo==="sangria"?"Sangria":"Suprimento"} · <span class="sub">${esc(m.motivo||"")} ${hora(m.criado_em)}</span></span>
        <span class="num" style="color:${m.tipo==="sangria"?"var(--red)":"var(--green)"}">${m.tipo==="sangria"?"-":"+"} ${money(m.valor)}</span></div>`).join(""):`<p class="sub">Nenhuma movimentação.</p>`}</div>
  </div>
  <div class="toolbar" style="margin-top:18px">
    <button class="btn btn-out" id="sup">Registrar suprimento</button>
    <button class="btn btn-out" id="san">Registrar sangria</button>
    <button class="btn btn-pri" id="fec">Fechar caixa</button></div>`;
  $("#sup").onclick=()=>movimento("suprimento");
  $("#san").onclick=()=>movimento("sangria");
  $("#fec").onclick=()=>fecharCaixa(r,esperado);
}
function movimento(tipo){
  const t=tipo==="sangria"?"Sangria — retirada de dinheiro":"Suprimento — entrada de dinheiro";
  $("#modalRoot").innerHTML=`<div class="overlay"><div class="modal"><h3>${t}</h3>
    <div class="campo"><label>Valor</label><input id="mv" type="number" step="0.01" autofocus></div>
    <div class="campo"><label>Motivo</label><input id="mo" placeholder="${tipo==="sangria"?"Ex.: depósito, pagamento de fornecedor":"Ex.: reforço de troco"}"></div>
    <div class="mfoot"><button class="btn btn-out" id="c2" style="flex:1">Cancelar</button>
      <button class="btn btn-go" id="s2" style="flex:1">Registrar</button></div></div></div>`;
  $("#c2").onclick=fecharModal;
  $("#s2").onclick=async()=>{
    const v=+$("#mv").value||0;if(v<=0){toast("Informe o valor");return}
    await sb.from("caixa_movimentos").insert({caixa_id:caixa.id,tipo,valor:v,motivo:$("#mo").value,criado_por:perfil.id});
    fecharModal();renderCaixa();toast("Registrado")};
}
function fecharCaixa(r,esperado){
  $("#modalRoot").innerHTML=`<div class="overlay"><div class="modal"><h3>Fechamento de caixa</h3>
    <p class="sub" style="margin-bottom:14px">Conte o dinheiro da gaveta e informe o valor real. O sistema compara com o esperado.</p>
    <div class="faixa"><span>Esperado na gaveta</span><b class="num">${money(esperado)}</b></div>
    <div class="campo"><label>Valor contado</label><input id="vc" type="number" step="0.01" autofocus></div>
    <div class="faixa"><span>Diferença</span><b class="num" id="dif">R$ 0,00</b></div>
    <div class="campo"><label>Observação</label><input id="ob" placeholder="Opcional"></div>
    <div class="mfoot"><button class="btn btn-out" id="c3" style="flex:1">Cancelar</button>
      <button class="btn btn-pri" id="s3" style="flex:2">Fechar e imprimir</button></div></div></div>`;
  $("#vc").oninput=()=>{const d=(+$("#vc").value||0)-esperado;
    $("#dif").textContent=(d>=0?"+ ":"- ")+money(Math.abs(d));
    $("#dif").style.color=Math.abs(d)<0.01?"var(--ink)":(d<0?"var(--red)":"var(--green)")};
  $("#c3").onclick=fecharModal;
  $("#s3").onclick=async()=>{
    const vc=+$("#vc").value||0,d=vc-esperado;
    await sb.from("caixas").update({status:"fechado",fechado_em:new Date().toISOString(),
      fechado_por:perfil.id,valor_contado:vc,valor_sistema:esperado,diferenca:d,observacao:$("#ob").value}).eq("id",caixa.id);
    imprimir(cupomFecho(r,esperado,vc,d));
    fecharModal();await verCaixa();renderCaixa();toast("Caixa fechado")};
}
function cupomFecho(r,esp,vc,d){const f=r.formas||{};
 return `<div class="c b">FECHAMENTO DE CAIXA</div><div class="c">${esc(loja.nome)}</div>
<div class="c">${new Date().toLocaleDateString("pt-BR")} ${hora(new Date())}</div>
<div class="c">Operador: ${esc(perfil.nome)}</div><div class="hr"></div>
<table><tr><td>Abertura</td><td class="r">${money(r.abertura)}</td></tr>
<tr><td>Pedidos</td><td class="r">${r.pedidos}</td></tr>
<tr><td>Vendas</td><td class="r">${money(r.total)}</td></tr>
<tr><td>Suprimentos</td><td class="r">${money(r.suprimentos)}</td></tr>
<tr><td>Sangrias</td><td class="r">- ${money(r.sangrias)}</td></tr></table>
<div class="hr"></div><table>${Object.entries(f).map(([k,v])=>`<tr><td>${esc(k)}</td><td class="r">${money(v)}</td></tr>`).join("")}</table>
<div class="hr"></div><table>
<tr><td class="b">Esperado</td><td class="r b">${money(esp)}</td></tr>
<tr><td class="b">Contado</td><td class="r b">${money(vc)}</td></tr>
<tr><td class="b">Diferenca</td><td class="r b">${(d>=0?"+ ":"- ")+money(Math.abs(d))}</td></tr></table>
<div class="hr"></div><div class="c">Assinatura: ____________________</div><div style="height:16px"></div>`}
