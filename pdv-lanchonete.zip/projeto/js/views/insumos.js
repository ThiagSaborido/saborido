/* insumos.js — Estoque, validade e perdas
   Projeto: Sistema PDV/ERP Lanchonete */

/* ============ insumos ============ */
function renderInsumos(){
  const hj=hoje(),d30=new Date();d30.setDate(d30.getDate()+7);
  const prox=d30.toLocaleDateString("sv-SE");
  const vencidos=insumos.filter(i=>i.validade&&i.validade<hj);
  const vencendo=insumos.filter(i=>i.validade&&i.validade>=hj&&i.validade<=prox);
  const baixos=insumos.filter(i=>+i.estoque_atual<=+i.estoque_minimo);
  const valor=insumos.reduce((s,i)=>s+ +i.estoque_atual * +i.custo_unitario,0);
  const fn=id=>fornecedores.find(f=>f.id===id)?.nome||"—";
  $("#insumos").innerHTML=`<h2>Estoque de insumos</h2>
  <p class="sub">Controle de quantidade, validade e perdas. O atendente também registra baixa e perda.</p>
  <div class="kpis">
    <div class="kpi dest"><div class="lb">Estoque valorizado</div><div class="vl num">${money(valor)}</div></div>
    <div class="kpi"><div class="lb">Abaixo do mínimo</div><div class="vl num" style="color:${baixos.length?"var(--red)":"inherit"}">${baixos.length}</div></div>
    <div class="kpi"><div class="lb">Vencendo em 7 dias</div><div class="vl num" style="color:${vencendo.length?"var(--amber)":"inherit"}">${vencendo.length}</div></div>
    <div class="kpi"><div class="lb">Vencidos</div><div class="vl num" style="color:${vencidos.length?"var(--red)":"inherit"}">${vencidos.length}</div></div>
  </div>
  ${adm()?`<div class="toolbar"><button class="btn btn-pri sm" id="ai">Adicionar insumo</button></div>`:""}
  <div class="tabela"><table><thead><tr><th style="width:22%">Insumo</th><th style="width:70px">Un</th>
    <th style="width:100px">Estoque</th><th style="width:100px">Mínimo</th><th style="width:110px">Custo un.</th>
    <th style="width:130px">Validade</th><th>Fornecedor</th><th style="width:100px">Situação</th>
    <th style="width:190px">Movimentar</th></tr></thead><tbody>
    ${insumos.length?insumos.map(i=>{
      const venc=i.validade&&i.validade<hj,prx=i.validade&&i.validade>=hj&&i.validade<=prox;
      const bx=+i.estoque_atual<=+i.estoque_minimo;
      return `<tr data-id="${i.id}">
      <td>${adm()?`<input data-f="nome" value="${esc(i.nome)}">`:esc(i.nome)}</td>
      <td>${adm()?`<input data-f="unidade" value="${esc(i.unidade)}">`:esc(i.unidade)}</td>
      <td class="num"><b>${(+i.estoque_atual).toFixed(2)}</b></td>
      <td>${adm()?`<input data-f="estoque_minimo" type="number" step="0.01" value="${+i.estoque_minimo}">`:(+i.estoque_minimo).toFixed(2)}</td>
      <td>${adm()?`<input data-f="custo_unitario" type="number" step="0.0001" value="${+i.custo_unitario}">`:money(i.custo_unitario)}</td>
      <td>${adm()?`<input data-f="validade" type="date" value="${i.validade||""}">`:(i.validade?new Date(i.validade+"T12:00").toLocaleDateString("pt-BR"):"—")}</td>
      <td class="sub">${esc(fn(i.fornecedor_id))}</td>
      <td>${venc?'<span class="badge b-red">Vencido</span>':prx?'<span class="badge b-navy">Vence logo</span>':bx?'<span class="badge b-red">Repor</span>':'<span class="badge b-ok">OK</span>'}</td>
      <td><button class="btn btn-out sm" data-mv="${i.id}|entrada">Entrada</button>
          <button class="btn btn-out sm" data-mv="${i.id}|saida">Baixa</button>
          <button class="btn btn-del sm" data-mv="${i.id}|perda">Perda</button></td></tr>`}).join("")
      :`<tr><td colspan="9" class="sub" style="padding:26px;text-align:center">Nenhum insumo cadastrado.</td></tr>`}
  </tbody></table></div>`;
  if(adm()){
    $("#ai").onclick=async()=>{await sb.from("insumos").insert({nome:"Novo insumo"});
      await carregar("insumos","nome");renderInsumos()};
    $$("#insumos input").forEach(el=>el.onchange=async()=>{
      const id=el.closest("tr").dataset.id,f=el.dataset.f;
      const v=["estoque_minimo","custo_unitario"].includes(f)?(+el.value||0):(el.value||null);
      await salvarCampo("insumos",id,f,v);await carregar("insumos","nome");renderInsumos()});
  }
  $$("[data-mv]").forEach(b=>b.onclick=()=>{
    const [id,tipo]=b.dataset.mv.split("|");const ins=insumos.find(x=>x.id===id);
    const tt={entrada:"Entrada de estoque",saida:"Baixa de estoque",perda:"Registrar perda"}[tipo];
    $("#modalRoot").innerHTML=`<div class="overlay"><div class="modal"><h3>${tt}</h3>
      <p class="sub" style="margin-bottom:14px">${esc(ins.nome)} — estoque atual ${(+ins.estoque_atual).toFixed(2)} ${esc(ins.unidade)}</p>
      <div class="campo"><label>Quantidade</label><input id="qv" type="number" step="0.01" autofocus></div>
      <div class="campo"><label>Motivo</label><input id="mt" placeholder="${tipo==="perda"?"Ex.: vencido, quebrado, queimou":"Opcional"}"></div>
      <div class="mfoot"><button class="btn btn-out" id="c4" style="flex:1">Cancelar</button>
        <button class="btn btn-go" id="s4" style="flex:1">Confirmar</button></div></div></div>`;
    $("#c4").onclick=fecharModal;
    $("#s4").onclick=async()=>{const q=+$("#qv").value||0;if(q<=0){toast("Informe a quantidade");return}
      await sb.from("insumo_movimentos").insert({insumo_id:id,tipo,quantidade:q,
        custo_total:q*(+ins.custo_unitario),motivo:$("#mt").value,criado_por:perfil.id});
      fecharModal();await carregar("insumos","nome");renderInsumos();toast("Movimentação registrada")}});
}
