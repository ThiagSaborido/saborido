/* fidelidade.js — Cartao fidelidade
   Projeto: Sistema PDV/ERP Lanchonete */

/* ============ fidelidade ============ */
async function carregarFidelidade(){
  const a=await sb.from("vw_fidelidade").select("*").order("carimbos",{ascending:false});
  cartoes=a.data||[];
  const b=await sb.from("fidelidade_regras").select("*").order("nome");
  regras=b.data||[];
}
function renderFidelidade(){
  const prontos=cartoes.filter(c=>c.pode_resgatar);
  $("#fidelidade").innerHTML=`<h2>Cartão fidelidade</h2>
  <p class="sub">Cada pedido acima do valor mínimo carimba o cartão do cliente automaticamente. Nada para o atendente lembrar de fazer.</p>
  <div class="kpis">
    <div class="kpi dest"><div class="lb">Prontos para resgatar</div><div class="vl num">${prontos.length}</div></div>
    <div class="kpi"><div class="lb">Cartões ativos</div><div class="vl num">${cartoes.length}</div></div>
    <div class="kpi"><div class="lb">Resgates já feitos</div><div class="vl num">${cartoes.reduce((s,c)=>s+c.resgates,0)}</div></div>
  </div>
  ${adm()?`<div class="bloco" style="margin-bottom:18px"><h3>Regras do programa</h3>
    <div class="tabela" style="box-shadow:none"><table><thead><tr><th>Nome</th>
      <th style="width:150px">Pedidos p/ prêmio</th><th style="width:150px">Valor mínimo</th>
      <th>Recompensa</th><th style="width:70px">Ativa</th></tr></thead><tbody>
      ${regras.map(r=>`<tr data-id="${r.id}">
        <td><input data-f="nome" value="${esc(r.nome)}"></td>
        <td><input data-f="pedidos_necessarios" type="number" value="${r.pedidos_necessarios}"></td>
        <td><input data-f="valor_minimo" type="number" step="0.01" value="${+r.valor_minimo}"></td>
        <td><input data-f="recompensa" value="${esc(r.recompensa)}"></td>
        <td><input type="checkbox" data-f="ativa" ${r.ativa?"checked":""}></td></tr>`).join("")}
    </tbody></table></div>
    <div class="toolbar" style="margin:14px 0 0"><button class="btn btn-out sm" id="ar">Nova regra</button></div></div>`:""}
  <div class="tabela"><table><thead><tr><th style="width:24%">Cliente</th><th style="width:140px">WhatsApp</th>
    <th style="width:230px">Progresso</th><th>Recompensa</th><th style="width:90px">Resgates</th>
    <th style="width:170px"></th></tr></thead><tbody>
    ${cartoes.length?cartoes.map(c=>{const pct=Math.min(100,Math.round(c.carimbos/c.pedidos_necessarios*100));
      return `<tr>
      <td><b>${esc(c.nome)}</b></td><td class="num sub">${esc(c.telefone||"—")}</td>
      <td><div style="display:flex;align-items:center;gap:9px">
        <div style="flex:1;height:7px;background:var(--line);border-radius:4px;overflow:hidden">
          <div style="height:100%;width:${pct}%;background:${c.pode_resgatar?"var(--green)":"var(--brand)"}"></div></div>
        <span class="num" style="font-size:12.5px;font-weight:600">${c.carimbos}/${c.pedidos_necessarios}</span></div></td>
      <td class="sub">${esc(c.recompensa)}</td><td class="num">${c.resgates}</td>
      <td>${c.pode_resgatar?`<button class="btn btn-go sm" data-rg="${c.id}">Resgatar</button>`:`<span class="badge b-navy">Faltam ${c.pedidos_necessarios-c.carimbos}</span>`}
        ${c.telefone&&c.pode_resgatar?`<button class="btn btn-out sm" data-av="${c.telefone}|${esc(c.nome)}|${esc(c.recompensa)}">Avisar</button>`:""}</td></tr>`}).join("")
      :`<tr><td colspan="6" class="sub" style="padding:30px;text-align:center">Nenhum cartão ainda. Eles aparecem sozinhos conforme os clientes cadastrados vão comprando.</td></tr>`}
  </tbody></table></div>`;
  if(adm()){
    $("#ar").onclick=async()=>{await sb.from("fidelidade_regras").insert({nome:"Nova regra"});
      await carregarFidelidade();renderFidelidade()};
    $$("#fidelidade input[data-f]").forEach(el=>el.onchange=async()=>{
      const id=el.closest("tr").dataset.id,f=el.dataset.f;
      const v=el.type==="checkbox"?el.checked:(["pedidos_necessarios","valor_minimo"].includes(f)?(+el.value||0):el.value);
      await salvarCampo("fidelidade_regras",id,f,v);await carregarFidelidade();renderFidelidade()});
  }
  $$("[data-rg]").forEach(b=>b.onclick=async()=>{
    const {data,error}=await sb.rpc("resgatar_fidelidade",{p_cartao:b.dataset.rg});
    if(error){toast(error.message);return}
    toast("Resgatado: "+data.recompensa);await carregarFidelidade();renderFidelidade()});
  $$("[data-av]").forEach(b=>b.onclick=()=>{
    const [tel,nome,rec]=b.dataset.av.split("|");
    const m=`Oi ${nome.split(" ")[0]}! Seu cartão fidelidade fechou. Você tem ${rec} esperando por você aqui.`;
    window.open(`https://wa.me/55${dig(tel)}?text=${encodeURIComponent(m)}`,"_blank")});
}
