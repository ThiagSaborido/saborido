/* fiscal.js — Consulta de NFC-e
   Projeto: Sistema PDV/ERP Lanchonete */

/* ============ documentos fiscais ============ */
function renderFiscal(){
  const hj=new Date(),ini=new Date(hj.getFullYear(),hj.getMonth(),1);
  const ld=docs.filter(d=>d.status==="autorizada");
  $("#fiscal").innerHTML=`<h2>Documentos fiscais</h2>
  <p class="sub">Consulta das NFC-e emitidas, filtro por período e download dos XMLs para o contador.</p>
  <div class="bloco" style="background:var(--brandSoft);border-color:#C9D9F8;margin-bottom:20px">
    <h3 style="color:#1E40AF">Emissão ainda não está ligada</h3>
    <p style="font-size:13.2px;color:#1E3A8A;line-height:1.6">Emitir NFC-e não depende de programação: exige certificado digital A1,
    credenciamento na SEFAZ do seu estado e uma conta em um integrador (Focus NFe, NFe.io e similares), que cobram mensalidade.
    A estrutura já está pronta aqui — quando você tiver certificado e conta, a emissão passa a gravar direto nesta tela.
    Até lá o comprovante impresso no fechamento do pedido serve para o cliente, mas não substitui nota fiscal.</p></div>
  <div class="kpis">
    <div class="kpi dest"><div class="lb">Notas autorizadas</div><div class="vl num">${ld.length}</div></div>
    <div class="kpi"><div class="lb">Valor total</div><div class="vl num">${money(ld.reduce((s,d)=>s+ +d.valor,0))}</div></div>
    <div class="kpi"><div class="lb">Canceladas</div><div class="vl num">${docs.filter(d=>d.status==="cancelada").length}</div></div>
    <div class="kpi"><div class="lb">Com erro</div><div class="vl num">${docs.filter(d=>d.status==="erro").length}</div></div>
  </div>
  <div class="toolbar">
    <div class="campo" style="margin:0"><label>De</label><input id="fdi" type="date" value="${ini.toLocaleDateString("sv-SE")}"></div>
    <div class="campo" style="margin:0"><label>Até</label><input id="fdf" type="date" value="${hoje()}"></div>
    <button class="btn btn-out sm" id="fbx" style="margin-top:18px">Baixar XMLs do período</button></div>
  <div class="tabela"><table><thead><tr><th style="width:110px">Número</th><th style="width:90px">Tipo</th>
    <th>Chave de acesso</th><th style="width:120px">Valor</th><th style="width:160px">Emissão</th>
    <th style="width:120px">Situação</th><th style="width:100px">XML</th></tr></thead><tbody>
    ${docs.length?docs.map(d=>`<tr>
      <td class="num">${esc(d.numero||"—")}</td><td>${esc(d.tipo)}</td>
      <td class="sub num" style="font-size:11.5px">${esc(d.chave||"—")}</td>
      <td class="num">${money(d.valor)}</td>
      <td class="num">${d.emitido_em?new Date(d.emitido_em).toLocaleString("pt-BR"):"—"}</td>
      <td><span class="badge ${d.status==="autorizada"?"b-ok":d.status==="erro"?"b-red":"b-navy"}">${esc(d.status)}</span></td>
      <td>${d.xml_url?`<a class="btn btn-out sm" href="${esc(d.xml_url)}" target="_blank">Baixar</a>`:"—"}</td></tr>`).join("")
      :`<tr><td colspan="7" class="sub" style="padding:34px;text-align:center">Nenhum documento emitido ainda.</td></tr>`}
  </tbody></table></div>`;
  $("#fbx").onclick=()=>{
    const a=$("#fdi").value,b=$("#fdf").value;
    const l=docs.filter(d=>d.xml_url&&d.emitido_em&&d.emitido_em.slice(0,10)>=a&&d.emitido_em.slice(0,10)<=b);
    if(!l.length){toast("Nenhum XML no período");return}
    l.forEach(d=>window.open(d.xml_url,"_blank"))};
}
