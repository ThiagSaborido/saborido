/* whatsapp.js — Modelos e campanhas
   Projeto: Sistema PDV/ERP Lanchonete */

/* ============ automações WhatsApp ============ */
const FILT={todos:["Todos os clientes",()=>true],
 sumidos:["Não compram há 30 dias",c=>diasC(c)>=30],
 recentes:["Compraram nos últimos 15 dias",c=>diasC(c)<=15],
 fieis:["3 pedidos ou mais",c=>c.qtd_pedidos>=3],
 vip:["Gastaram mais de R$ 150",c=>+c.total_gasto>150]};
const diasC=c=>c.ultimo_pedido?Math.floor((Date.now()-new Date(c.ultimo_pedido))/864e5):9999;
let filtroW="todos",campanhaW=null;
const alvoW=()=>clientes.filter(c=>c.telefone&&c.aceita_promocao&&FILT[filtroW][1](c));
function montaMsg(m,c){return (m||"")
  .replace(/\{nome\}/g,(c.nome||"").split(" ")[0])
  .replace(/\{promocao\}/g,$("#varPromo")?.value||"")
  .replace(/\{recompensa\}/g,$("#varRec")?.value||"")}

function renderWhatsapp(){
  const l=alvoW();
  $("#whatsapp").innerHTML=`<h2>Automações WhatsApp</h2>
  <p class="sub">Crie modelos reutilizáveis, escolha o público e dispare. O app abre cada conversa com a mensagem pronta.</p>
  <div class="bloco" style="background:var(--amberSoft);border-color:#F0DCBB;margin-bottom:20px">
    <h3 style="color:#8A4B08">Envio assistido, e por um bom motivo</h3>
    <p style="font-size:13.2px;color:#6B5518;line-height:1.6">Disparo automático em massa pelo WhatsApp Web viola os termos
    do WhatsApp e derruba o número — e um número banido leva junto toda a sua base de clientes. Aqui você confirma cada envio,
    o que leva uns 4 segundos por cliente. Para disparo automático de verdade existe a API oficial do WhatsApp Business,
    com conta aprovada e modelos homologados; o botão de exportar gera a lista já no formato dela.</p></div>
  <div class="dois" style="grid-template-columns:340px 1fr">
    <div>
      <div class="bloco" style="margin-bottom:16px"><h3>Meus modelos</h3>
        <div id="listaT"></div>
        <div class="toolbar" style="margin:14px 0 0"><button class="btn btn-out sm" id="novoT">Novo modelo</button></div></div>
      <div class="bloco"><h3>Quem vai receber</h3>
        <div style="display:flex;flex-direction:column;gap:7px">
          ${Object.entries(FILT).map(([k,[t,f]])=>{
            const n=clientes.filter(c=>c.telefone&&c.aceita_promocao&&f(c)).length;
            return `<button class="btn ${k===filtroW?"btn-pri":"btn-out"} sm" data-fw="${k}"
              style="justify-content:space-between">${t}<b>${n}</b></button>`}).join("")}</div></div>
    </div>
    <div>
      <div class="bloco" style="margin-bottom:16px"><h3>Mensagem</h3>
        <div class="campo"><label>Usar um modelo</label>
          <select id="selTpl"><option value="">— escrever do zero —</option>
            ${templates.map(t=>`<option value="${t.id}">${esc(t.nome)} · ${esc(t.categoria||"")}</option>`).join("")}</select></div>
        <div class="campo"><label>Texto</label><textarea id="msgW" placeholder="Oi {nome}! Hoje tem..."></textarea>
          <p class="sub" style="margin-top:6px">Variáveis: {nome}, {promocao}, {recompensa}</p></div>
        <div class="dois" style="gap:10px">
          <div class="campo"><label>Valor de {promocao}</label><input id="varPromo" placeholder="X-Bacon por R$ 19,90"></div>
          <div class="campo"><label>Valor de {recompensa}</label><input id="varRec" placeholder="um lanche grátis"></div></div>
        <div class="toolbar" style="margin:6px 0 0">
          <button class="btn btn-go sm" id="iniW">Iniciar envio (${l.length})</button>
          <button class="btn btn-out sm" id="salvarT">Salvar como modelo</button>
          <button class="btn btn-out sm" id="expW">Exportar lista</button></div></div>
      <div id="painelW"></div>
    </div>
  </div>`;
  const pintaT=()=>{$("#listaT").innerHTML=templates.length?templates.map(t=>`<div class="rank">
      <span style="cursor:pointer" data-usa="${t.id}"><b>${esc(t.nome)}</b><br><span class="sub">${esc(t.mensagem.slice(0,54))}${t.mensagem.length>54?"…":""}</span></span>
      <button class="btn btn-del sm" data-dt="${t.id}">Excluir</button></div>`).join("")
      :`<p class="sub">Nenhum modelo salvo.</p>`;
    $$("[data-usa]").forEach(e=>e.onclick=()=>{const t=templates.find(x=>x.id===e.dataset.usa);
      $("#selTpl").value=t.id;$("#msgW").value=t.mensagem;toast("Modelo carregado")});
    $$("[data-dt]").forEach(b=>b.onclick=async()=>{if(!confirm("Excluir modelo?"))return;
      await sb.from("wa_templates").delete().eq("id",b.dataset.dt);
      await carregar("wa_templates","nome");renderWhatsapp()})};
  pintaT();
  $("#selTpl").onchange=()=>{const t=templates.find(x=>x.id===$("#selTpl").value);
    if(t)$("#msgW").value=t.mensagem};
  $$("[data-fw]").forEach(b=>b.onclick=()=>{filtroW=b.dataset.fw;renderWhatsapp()});
  $("#novoT").onclick=()=>modalTemplate();
  $("#salvarT").onclick=()=>{const m=$("#msgW").value.trim();
    if(!m){toast("Escreva a mensagem primeiro");return}modalTemplate(m)};
  $("#expW").onclick=()=>{const rows=[["Nome","Telefone","Mensagem"]];
    alvoW().forEach(c=>rows.push([c.nome,"55"+c.telefone,montaMsg($("#msgW").value,c)]));
    baixar(`campanha-${hoje()}.csv`,"\uFEFF"+rows.map(r=>r.join(";")).join("\n"))};
  $("#iniW").onclick=()=>{const m=$("#msgW").value.trim();
    if(!m){toast("Escreva a mensagem");return}
    if(!alvoW().length){toast("Nenhum cliente nesse filtro");return}
    campanhaW={msg:m,lista:alvoW(),ix:0,env:0,tpl:$("#selTpl").value||null};envioW()};
}
function modalTemplate(pre){
  $("#modalRoot").innerHTML=`<div class="overlay"><div class="modal"><h3>Novo modelo</h3>
    <div class="campo"><label>Nome do modelo</label><input id="tn" placeholder="Ex.: Status do pedido"></div>
    <div class="campo"><label>Categoria</label><input id="tc" value="Promocao"></div>
    <div class="campo"><label>Mensagem</label><textarea id="tm">${esc(pre||"")}</textarea>
      <p class="sub" style="margin-top:6px">Use {nome}, {promocao} e {recompensa}.</p></div>
    <div class="mfoot"><button class="btn btn-out" id="c6" style="flex:1">Cancelar</button>
      <button class="btn btn-go" id="s6" style="flex:1">Salvar modelo</button></div></div></div>`;
  $("#c6").onclick=fecharModal;
  $("#s6").onclick=async()=>{const n=$("#tn").value.trim(),m=$("#tm").value.trim();
    if(!n||!m){toast("Preencha nome e mensagem");return}
    await sb.from("wa_templates").insert({nome:n,categoria:$("#tc").value,mensagem:m});
    fecharModal();await carregar("wa_templates","nome");renderWhatsapp();toast("Modelo salvo")};
}
function envioW(){
  const c=campanhaW;
  if(c.ix>=c.lista.length){
    $("#painelW").innerHTML=`<div class="bloco"><h3>Campanha concluída</h3>
      <p class="sub" style="margin-top:6px">${c.env} de ${c.lista.length} clientes contatados.</p></div>`;
    campanhaW=null;return}
  const cl=c.lista[c.ix],pct=Math.round(c.ix/c.lista.length*100);
  $("#painelW").innerHTML=`<div class="bloco"><h3>Enviando ${c.ix+1} de ${c.lista.length}</h3>
    <div style="height:7px;background:var(--line);border-radius:4px;overflow:hidden;margin:12px 0">
      <div style="height:100%;width:${pct}%;background:var(--green);transition:width .2s"></div></div>
    <div class="faixa" style="display:block">
      <div style="font-weight:660;font-size:16px">${esc(cl.nome)}</div>
      <div class="sub num">+55 ${esc(cl.telefone)} · ${cl.qtd_pedidos} pedidos · ${money(cl.total_gasto)}</div></div>
    <div class="campo"><label>Mensagem que vai abrir</label>
      <div style="background:#F8FAFC;border:1px solid var(--line);border-radius:var(--rs);padding:13px;font-size:13.5px;white-space:pre-wrap">${esc(montaMsg(c.msg,cl))}</div></div>
    <div class="mfoot"><button class="btn btn-out" id="pulaW" style="flex:1">Pular</button>
      <button class="btn btn-go" id="abreW" style="flex:2">Abrir no WhatsApp</button></div></div>`;
  $("#abreW").onclick=async()=>{
    window.open(`https://wa.me/55${cl.telefone}?text=${encodeURIComponent(montaMsg(c.msg,cl))}`,"_blank");
    await sb.from("wa_envios").insert({template_id:c.tpl,cliente_id:cl.id});
    c.env++;c.ix++;setTimeout(envioW,400)};
  $("#pulaW").onclick=()=>{c.ix++;envioW()};
}
