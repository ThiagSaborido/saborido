/* equipe.js — Funcionarios e escala
   Projeto: Sistema PDV/ERP Lanchonete */

/* ============ equipe ============ */
const DIAS=["Domingo","Segunda","Terça","Quarta","Quinta","Sexta","Sábado"];
function renderEquipe(){
  const folha=funcionarios.filter(f=>f.ativo).reduce((s,f)=>s+ +f.salario+ +f.vale,0);
  $("#equipe").innerHTML=`<h2>Equipe e escala</h2>
  <p class="sub">Salário, vale e escala por dia da semana. Clique em Escala para definir horários e folgas.</p>
  <div class="kpis">
    <div class="kpi dest"><div class="lb">Folha mensal (salário + vale)</div><div class="vl num">${money(folha)}</div></div>
    <div class="kpi"><div class="lb">Com encargos estimados (+35%)</div><div class="vl num">${money(folha*1.35)}</div></div>
    <div class="kpi"><div class="lb">Funcionários ativos</div><div class="vl num">${funcionarios.filter(f=>f.ativo).length}</div></div>
  </div>
  <div class="toolbar"><button class="btn btn-pri sm" id="afu">Adicionar funcionário</button></div>
  <div class="tabela"><table><thead><tr><th style="width:22%">Nome</th><th>Cargo</th><th style="width:120px">Salário</th>
    <th style="width:110px">Vale</th><th style="width:110px">Contrato</th><th style="width:140px">Telefone</th>
    <th style="width:70px">Ativo</th><th style="width:150px"></th></tr></thead><tbody>
    ${funcionarios.length?funcionarios.map(f=>`<tr data-id="${f.id}">
      <td><input data-f="nome" value="${esc(f.nome)}"></td>
      <td><input data-f="cargo" value="${esc(f.cargo||"")}"></td>
      <td><input data-f="salario" type="number" step="0.01" value="${+f.salario}"></td>
      <td><input data-f="vale" type="number" step="0.01" value="${+f.vale}"></td>
      <td><input data-f="tipo_contrato" value="${esc(f.tipo_contrato||"")}"></td>
      <td><input data-f="telefone" value="${esc(f.telefone||"")}"></td>
      <td><input type="checkbox" data-f="ativo" ${f.ativo?"checked":""} style="width:auto"></td>
      <td><button class="btn btn-out sm" data-esc="${f.id}">Escala</button>
          <button class="btn btn-del sm" data-dfu="${f.id}">Excluir</button></td></tr>`).join("")
      :`<tr><td colspan="8" class="sub" style="padding:26px;text-align:center">Nenhum funcionário cadastrado.</td></tr>`}
  </tbody></table></div>
  <div class="bloco" style="margin-top:16px"><h3>Escala da semana</h3>
    <div class="tabela" style="box-shadow:none"><table><thead><tr><th>Funcionário</th>
      ${DIAS.map(d=>`<th style="text-align:center">${d.slice(0,3)}</th>`).join("")}</tr></thead><tbody>
      ${funcionarios.filter(f=>f.ativo).map(f=>`<tr><td><b>${esc(f.nome)}</b></td>
        ${DIAS.map((_,i)=>{const e=escalas.find(x=>x.funcionario_id===f.id&&x.dia_semana===i);
          return `<td style="text-align:center" class="sub">${!e?"—":e.folga?"Folga":`${(e.entrada||"").slice(0,5)}<br>${(e.saida||"").slice(0,5)}`}</td>`}).join("")}
      </tr>`).join("")||`<tr><td colspan="8" class="sub" style="padding:20px;text-align:center">Cadastre um funcionário para montar a escala.</td></tr>`}
    </tbody></table></div></div>`;
  $("#afu").onclick=async()=>{await sb.from("funcionarios").insert({nome:"Novo funcionário"});
    await carregar("funcionarios","nome");renderEquipe()};
  $$("#equipe input[data-f]").forEach(el=>editar(el,"funcionarios",["salario","vale"]));
  $$("[data-dfu]").forEach(b=>b.onclick=async()=>{if(!confirm("Excluir?"))return;
    await sb.from("funcionarios").delete().eq("id",b.dataset.dfu);
    await carregar("funcionarios","nome");await carregar("escalas","dia_semana");renderEquipe()});
  $$("[data-esc]").forEach(b=>b.onclick=()=>modalEscala(b.dataset.esc));
}
function modalEscala(fid){
  const f=funcionarios.find(x=>x.id===fid);
  $("#modalRoot").innerHTML=`<div class="overlay"><div class="modal"><h3>Escala — ${esc(f.nome)}</h3>
    ${DIAS.map((d,i)=>{const e=escalas.find(x=>x.funcionario_id===fid&&x.dia_semana===i)||{};
      return `<div class="linha" style="align-items:center;margin-bottom:8px" data-dia="${i}">
        <span style="flex:0 0 74px;font-size:13px;font-weight:600">${d}</span>
        <label style="flex:0 0 74px;font-size:12.5px;display:flex;gap:5px;align-items:center;margin:0">
          <input type="checkbox" class="fg" ${e.folga?"checked":""} style="width:auto">Folga</label>
        <input type="time" class="en" value="${(e.entrada||"").slice(0,5)}" ${e.folga?"disabled":""}>
        <input type="time" class="sa" value="${(e.saida||"").slice(0,5)}" ${e.folga?"disabled":""}></div>`}).join("")}
    <div class="mfoot"><button class="btn btn-out" id="c5" style="flex:1">Cancelar</button>
      <button class="btn btn-go" id="s5" style="flex:1">Salvar escala</button></div></div></div>`;
  $$("[data-dia] .fg").forEach(c=>c.onchange=()=>{const l=c.closest("[data-dia]");
    l.querySelector(".en").disabled=c.checked;l.querySelector(".sa").disabled=c.checked});
  $("#c5").onclick=fecharModal;
  $("#s5").onclick=async()=>{
    for(const l of $$("[data-dia]")){
      const dia=+l.dataset.dia,folga=l.querySelector(".fg").checked;
      const en=l.querySelector(".en").value||null,sa=l.querySelector(".sa").value||null;
      await sb.from("escalas").upsert({funcionario_id:fid,dia_semana:dia,folga,
        entrada:folga?null:en,saida:folga?null:sa},{onConflict:"funcionario_id,dia_semana"});
    }
    fecharModal();await carregar("escalas","dia_semana");renderEquipe();toast("Escala salva")};
}
