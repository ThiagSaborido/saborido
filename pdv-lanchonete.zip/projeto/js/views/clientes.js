/* clientes.js — Cadastro de clientes
   Projeto: Sistema PDV/ERP Lanchonete */

/* ============ clientes ============ */
function renderClientes(){
  $("#clientes").innerHTML=`<h2>Clientes</h2>
  <p class="sub">Cadastre os fixos para selecionar na venda sem redigitar. ${clientes.length} no total.</p>
  <div class="toolbar"><button class="btn btn-pri sm" id="ac">Cadastrar cliente</button>
    <button class="btn btn-out sm" id="ec">Exportar CSV</button></div>
  <div class="tabela"><table><thead><tr><th>Nome</th><th>WhatsApp</th><th>Endereço</th>
    <th style="width:80px">Pedidos</th><th style="width:110px">Total gasto</th><th style="width:100px">Promoções</th><th style="width:90px"></th></tr></thead>
  <tbody>${clientes.length?clientes.map(c=>`<tr data-id="${c.id}">
    <td><input data-f="nome" value="${esc(c.nome)}"></td>
    <td><input data-f="telefone" value="${esc(c.telefone||"")}"></td>
    <td><input data-f="endereco" value="${esc(c.endereco||"")}"></td>
    <td class="num">${c.qtd_pedidos}</td><td class="num">${money(c.total_gasto)}</td>
    <td><input type="checkbox" data-f="aceita_promocao" ${c.aceita_promocao?"checked":""} style="width:auto"></td>
    <td><button class="btn btn-del sm" data-dc="${c.id}">Remover</button></td></tr>`).join("")
    :`<tr><td colspan="7" class="sub" style="padding:26px;text-align:center">Nenhum cliente cadastrado.</td></tr>`}</tbody></table></div>`;
  $("#ac").onclick=async()=>{const n=prompt("Nome:");if(!n)return;
    const f=dig(prompt("WhatsApp com DDD:")||"");
    const {error}=await sb.from("clientes").insert({nome:n,telefone:f||null});
    if(error)toast("Telefone já cadastrado");await carregarClientes();renderClientes()};
  $("#ec").onclick=()=>{const l=[["Nome","Telefone","Endereco","Pedidos","Total"]];
    clientes.forEach(c=>l.push([c.nome,c.telefone||"",c.endereco||"",c.qtd_pedidos,String(c.total_gasto).replace(".",",")]));
    baixar(`clientes-${hoje()}.csv`,"\uFEFF"+l.map(r=>r.join(";")).join("\n"))};
  $$("#clientes input").forEach(el=>el.onchange=async()=>{
    const id=el.closest("tr").dataset.id,f=el.dataset.f;
    const v=el.type==="checkbox"?el.checked:(f==="telefone"?dig(el.value):el.value);
    await sb.from("clientes").update({[f]:v||null}).eq("id",id);await carregarClientes()});
  $$("[data-dc]").forEach(b=>b.onclick=async()=>{if(!confirm("Remover?"))return;
    await sb.from("clientes").delete().eq("id",b.dataset.dc);await carregarClientes();renderClientes()});
}
