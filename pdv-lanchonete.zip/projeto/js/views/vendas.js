/* vendas.js — PDV
   Projeto: Sistema PDV/ERP Lanchonete */

/* ============ catálogo e carrinho ============ */
function cats(){const c=["Todos",...new Set(produtos.map(p=>p.categoria))];
  $("#cats").innerHTML=c.map(x=>`<button data-c="${esc(x)}" class="${x===catAtual?"on":""}">${esc(x)}</button>`).join("");
  $$("#cats button").forEach(b=>b.onclick=()=>{catAtual=b.dataset.c;cats();grid()})}
function filtrados(){const q=$("#busca").value.trim().toLowerCase();
  return produtos.filter(p=>(catAtual==="Todos"||p.categoria===catAtual)&&(!q||p.nome.toLowerCase().includes(q)))}
function grid(){const l=filtrados();
  $("#grid").innerHTML=l.length?l.map((p,i)=>`<button class="tile" data-id="${p.id}">
    <div class="nome">${esc(p.nome)}</div><div class="preco num">${money(p.preco)}</div>
    ${i<9?`<div class="key">Alt+${i+1}</div>`:""}</button>`).join(""):`<div class="empty">Nenhum produto encontrado.</div>`;
  $$(".tile").forEach(t=>t.onclick=()=>add(t.dataset.id))}
function add(id){const p=produtos.find(x=>String(x.id)===String(id));if(!p)return;
  const ex=carrinho.find(i=>String(i.produto_id)===String(id)&&!i.obs);
  if(ex)ex.qtd++;else carrinho.push({produto_id:p.id,nome:p.nome,preco:+p.preco,qtd:1,obs:""});comanda()}
const totalCar=()=>carrinho.reduce((s,i)=>s+i.preco*i.qtd,0);
function comanda(){
  $("#itens").innerHTML=carrinho.length?carrinho.map((i,x)=>`<div class="item">
    <div class="qty"><button data-m="${x}">−</button><span class="num">${i.qtd}</span><button data-p="${x}">+</button></div>
    <div class="info"><div class="n">${esc(i.nome)}</div>${i.obs?`<div class="obs">${esc(i.obs)}</div>`:""}
      <div class="un num">${money(i.preco)} cada</div>
      <button class="linkbtn" data-o="${x}">${i.obs?"editar observação":"adicionar observação"}</button></div>
    <div class="val num">${money(i.preco*i.qtd)}</div></div>`).join("")
    :`<div class="vazio">Clique num produto para começar.<br>O pedido sai no nome do cliente.</div>`;
  $$("[data-m]").forEach(b=>b.onclick=()=>{const x=+b.dataset.m;carrinho[x].qtd--;if(carrinho[x].qtd<=0)carrinho.splice(x,1);comanda()});
  $$("[data-p]").forEach(b=>b.onclick=()=>{carrinho[+b.dataset.p].qtd++;comanda()});
  $$("[data-o]").forEach(b=>b.onclick=()=>{const x=+b.dataset.o;const v=prompt("Observação do item:",carrinho[x].obs||"");if(v!==null){carrinho[x].obs=v.trim();comanda()}});
  $("#totalTxt").textContent=money(totalCar());
  $("#btnPagar").disabled=!carrinho.length;
}
$("#btnLimpar").onclick=()=>{if(carrinho.length&&confirm("Cancelar este pedido?")){carrinho=[];clienteSel=null;$("#cliente").value="";$("#fone").value="";comanda();$("#busca").focus()}};
$$("#tipo button").forEach(b=>b.onclick=()=>{$$("#tipo button").forEach(x=>x.classList.remove("on"));b.classList.add("on");tipoAtual=b.dataset.t});

/* ============ clientes fixos ============ */
$("#btnFixo").onclick=()=>{
  if(!clientes.length){toast("Nenhum cliente cadastrado ainda");return}
  $("#modalRoot").innerHTML=`<div class="overlay"><div class="modal"><h3>Clientes cadastrados</h3>
    <div class="campo"><input id="bc" placeholder="Buscar por nome ou telefone" autocomplete="off"></div>
    <div id="listaC" style="max-height:44vh;overflow-y:auto"></div>
    <div class="mfoot"><button class="btn btn-out" id="fc" style="flex:1">Fechar</button></div></div></div>`;
  const pinta=()=>{const q=$("#bc").value.toLowerCase();
    const l=clientes.filter(c=>c.nome.toLowerCase().includes(q)||(c.telefone||"").includes(q)).slice(0,40);
    $("#listaC").innerHTML=l.length?l.map(c=>`<div class="rank" style="cursor:pointer" data-sel="${c.id}">
      <span><b>${esc(c.nome)}</b><br><span class="sub">${esc(c.telefone||"sem telefone")} · ${c.qtd_pedidos} pedidos</span></span>
      <span class="sub">selecionar</span></div>`).join(""):`<p class="sub">Nenhum resultado.</p>`;
    $$("[data-sel]").forEach(e=>e.onclick=()=>{
      const c=clientes.find(x=>x.id===e.dataset.sel);
      clienteSel=c.id;$("#cliente").value=c.nome;$("#fone").value=c.telefone||"";
      fecharModal();toast("Cliente selecionado")})};
  $("#bc").oninput=pinta;$("#fc").onclick=fecharModal;pinta();$("#bc").focus();
};

/* ============ pagamento ============ */
function fecharModal(){$("#modalRoot").innerHTML="";document.removeEventListener("keydown",escK)}
function escK(e){if(e.key==="Escape")fecharModal()}
$("#btnPagar").onclick=pagar;
function pagar(){
  if(!carrinho.length)return;
  if(!caixa){toast("Abra o caixa antes de vender");ir("caixa");return}
  const nome=$("#cliente").value.trim();
  if(!nome){$("#cliente").focus();toast("Informe o nome do cliente");return}
  const bruto=totalCar();let forma=null,desc=0;
  $("#modalRoot").innerHTML=`<div class="overlay"><div class="modal">
    <h3>Fechar pedido — ${esc(nome)}</h3>
    <div class="faixa"><span>Subtotal</span><b class="num">${money(bruto)}</b></div>
    <div class="campo"><label>Desconto em R$ (opcional)</label>
      <input id="desc" type="number" step="0.01" placeholder="0,00"></div>
    <div class="faixa"><span>Total a receber</span><b class="num" id="tot">${money(bruto)}</b></div>
    <div class="campo"><label>Forma de pagamento — obrigatória</label>
      <div class="pgs" id="pgs">
        <button data-f="Dinheiro">Dinheiro</button><button data-f="PIX">PIX</button>
        <button data-f="Debito">Cartão débito</button><button data-f="Credito">Cartão crédito</button></div></div>
    <div class="campo" id="boxRec" style="display:none"><label>Valor recebido</label>
      <input id="rec" type="number" step="0.01" placeholder="0,00"></div>
    <div class="faixa" id="boxTroco" style="display:none"><span>Troco</span><b class="num" id="tr">R$ 0,00</b></div>
    <div class="mfoot"><button class="btn btn-out" id="volta" style="flex:1">Voltar</button>
      <button class="btn btn-go" id="ok" style="flex:2">Confirmar e imprimir</button></div></div></div>`;
  const tot=()=>Math.max(bruto-desc,0);
  $("#desc").oninput=e=>{desc=+e.target.value||0;$("#tot").textContent=money(tot());calc()};
  const calc=()=>{const t=(+$("#rec").value||0)-tot();
    $("#tr").textContent=t<0?"faltam "+money(-t):money(t);
    $("#tr").style.color=t<0?"var(--red)":"var(--green)"};
  $("#rec").oninput=calc;
  $$("#pgs button").forEach(b=>b.onclick=()=>{
    $$("#pgs button").forEach(x=>x.classList.remove("on"));b.classList.add("on");forma=b.dataset.f;
    const d=forma==="Dinheiro";$("#boxRec").style.display=d?"":"none";$("#boxTroco").style.display=d?"":"none";
    if(d){$("#rec").focus();calc()}});
  $("#volta").onclick=fecharModal;
  $("#ok").onclick=()=>{
    if(!forma){toast("Escolha a forma de pagamento");return}
    const t=tot(),r=forma==="Dinheiro"?(+$("#rec").value||t):t;
    if(forma==="Dinheiro"&&r<t){toast("Valor recebido menor que o total");return}
    concluir(nome,forma,r,t,desc)};
  document.addEventListener("keydown",escK);
}
function proxN(){const n=[...filaView.map(p=>p.numero),...pend.filter(p=>p.data===hoje()).map(p=>p.numero)];
  return (n.length?Math.max(...n):0)+1}
function concluir(nome,forma,recebido,total,desconto){
  const p={uid:crypto.randomUUID(),numero:proxN(),data:hoje(),cliente_id:clienteSel||"",
    cliente_nome:nome,cliente_telefone:dig($("#fone").value),canal:"PDV",tipo:tipoAtual,
    total,desconto,forma_pagamento:forma,recebido,troco:Math.max(recebido-total,0),
    caixa_id:caixa?.id||"",itens:carrinho.map(i=>({...i})),criado_em:new Date().toISOString()};
  pend.push(p);LS.set("s.pend",pend);
  imprimir(comandaCozinha(p));setTimeout(()=>imprimir(comprovante(p)),700);
  carrinho=[];clienteSel=null;$("#cliente").value="";$("#fone").value="";$("#busca").value="";
  fecharModal();comanda();grid();toast(`Pedido ${String(p.numero).padStart(3,"0")} concluído`);
  $("#busca").focus();sincronizar();
}
