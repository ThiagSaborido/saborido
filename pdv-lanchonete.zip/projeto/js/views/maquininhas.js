/* maquininhas.js — Taxas e comparador
   Projeto: Sistema PDV/ERP Lanchonete */

/* ============ maquininhas ============ */
function renderMaquininhas(){
  const ex=1000;
  $("#maquininhas").innerHTML=`<h2>Maquininhas e taxas</h2>
  <p class="sub">Compare quanto cada uma te custa. A simulação abaixo usa R$ 1.000 de venda em cada modalidade.</p>
  <div class="toolbar"><button class="btn btn-pri sm" id="am">Adicionar maquininha</button></div>
  <div class="tabela"><table><thead><tr><th style="width:20%">Nome</th><th style="width:110px">Débito %</th>
    <th style="width:110px">Crédito %</th><th style="width:130px">Parcelado %</th><th style="width:100px">PIX %</th>
    <th style="width:110px">Prazo</th><th style="width:140px">Custo em R$ 1.000</th><th style="width:80px"></th></tr></thead><tbody>
    ${maquininhas.map(m=>{const custo=ex*(+m.taxa_debito+ +m.taxa_credito+ +m.taxa_credito_parcelado+ +m.taxa_pix)/100/4;
      return `<tr data-id="${m.id}">
      <td><input data-f="nome" value="${esc(m.nome)}"></td>
      <td><input data-f="taxa_debito" type="number" step="0.01" value="${+m.taxa_debito}"></td>
      <td><input data-f="taxa_credito" type="number" step="0.01" value="${+m.taxa_credito}"></td>
      <td><input data-f="taxa_credito_parcelado" type="number" step="0.01" value="${+m.taxa_credito_parcelado}"></td>
      <td><input data-f="taxa_pix" type="number" step="0.01" value="${+m.taxa_pix}"></td>
      <td><input data-f="prazo_recebimento" value="${esc(m.prazo_recebimento||"")}"></td>
      <td class="num"><b>${money(custo)}</b><br><span class="sub">média das 4 modalidades</span></td>
      <td><button class="btn btn-del sm" data-dm="${m.id}">Excluir</button></td></tr>`}).join("")}
  </tbody></table></div>
  <div class="bloco" style="margin-top:16px"><h3>Simulador por venda</h3>
    <div class="campo" style="max-width:260px"><label>Valor da venda</label><input id="sv" type="number" step="0.01" value="100"></div>
    <div id="simul"></div></div>`;
  $("#am").onclick=async()=>{await sb.from("maquininhas").insert({nome:"Nova maquininha"});
    await carregar("maquininhas","nome");renderMaquininhas()};
  $$("#maquininhas input[data-f]").forEach(el=>editar(el,"maquininhas",["taxa_debito","taxa_credito","taxa_credito_parcelado","taxa_pix"]));
  $$("[data-dm]").forEach(b=>b.onclick=async()=>{if(!confirm("Excluir?"))return;
    await sb.from("maquininhas").delete().eq("id",b.dataset.dm);await carregar("maquininhas","nome");renderMaquininhas()});
  const sim=()=>{const v=+$("#sv").value||0;
    $("#simul").innerHTML=maquininhas.map(m=>`<div class="rank"><span><b>${esc(m.nome)}</b></span>
      <span class="num">Débito ${money(v*(1-m.taxa_debito/100))} · Crédito ${money(v*(1-m.taxa_credito/100))} · Parcelado ${money(v*(1-m.taxa_credito_parcelado/100))}</span></div>`).join("")};
  $("#sv").oninput=sim;sim();
}
