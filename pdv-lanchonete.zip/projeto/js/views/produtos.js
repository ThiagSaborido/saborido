/* produtos.js — Cardapio e custos
   Projeto: Sistema PDV/ERP Lanchonete */

/* ============ produtos ============ */
function renderProdutos(){
  $("#produtos").innerHTML=`<h2>Cardápio</h2>
  <p class="sub">O custo fica em tabela separada — o atendente vê apenas o preço de venda.</p>
  <div class="toolbar"><button class="btn btn-pri sm" id="ap">Adicionar produto</button></div>
  <div class="tabela"><table><thead><tr><th style="width:34%">Nome</th><th>Categoria</th>
    <th style="width:120px">Preço</th><th style="width:120px">Custo</th><th style="width:90px">Margem</th><th style="width:90px"></th></tr></thead>
  <tbody>${produtos.map(p=>{const c=custos[p.id]||0;return `<tr data-id="${p.id}">
    <td><input data-f="nome" value="${esc(p.nome)}"></td>
    <td><input data-f="categoria" value="${esc(p.categoria)}"></td>
    <td><input data-f="preco" type="number" step="0.01" value="${+p.preco}"></td>
    <td><input data-f="custo" type="number" step="0.01" value="${c}"></td>
    <td class="num">${p.preco>0?Math.round((1-c/p.preco)*100)+"%":"—"}</td>
    <td><button class="btn btn-del sm" data-dp="${p.id}">Remover</button></td></tr>`}).join("")}</tbody></table></div>`;
  $("#ap").onclick=async()=>{
    const {data}=await sb.from("produtos").insert({nome:"Novo produto",categoria:"Lanches",preco:0,ordem:produtos.length+1}).select("id").single();
    if(data)await sb.from("produto_custos").insert({produto_id:data.id,custo:0});
    await base();await carregarCustos();renderProdutos();cats();grid()};
  $$("#produtos input").forEach(el=>el.onchange=async()=>{
    const id=el.closest("tr").dataset.id,f=el.dataset.f;
    if(f==="custo")await sb.from("produto_custos").upsert({produto_id:id,custo:+el.value||0});
    else await sb.from("produtos").update({[f]:f==="preco"?(+el.value||0):el.value}).eq("id",id);
    await base();await carregarCustos();renderProdutos();cats();grid()});
  $$("[data-dp]").forEach(b=>b.onclick=async()=>{if(!confirm("Remover do cardápio?"))return;
    await sb.from("produtos").update({ativo:false}).eq("id",b.dataset.dp);
    await base();renderProdutos();cats();grid()});
}
