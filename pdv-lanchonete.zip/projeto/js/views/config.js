/* config.js — Dados da loja e PIX
   Projeto: Sistema PDV/ERP Lanchonete */

/* ============ config ============ */
function renderConfig(){
  $("#config").innerHTML=`<h2>Configurações</h2><p class="sub">Dados que aparecem no comprovante e na mensagem de PIX.</p>
  <div class="dois">
    <div class="bloco"><h3>Estabelecimento</h3>
      <div class="campo"><label>Nome</label><input id="cn" value="${esc(loja.nome||"")}"></div>
      <div class="campo"><label>Telefone</label><input id="ct" value="${esc(loja.telefone||"")}"></div>
      <div class="campo"><label>Endereço</label><input id="ce" value="${esc(loja.endereco||"")}"></div>
      <button class="btn btn-pri" id="sl">Salvar</button></div>
    <div class="bloco"><h3>Chave PIX</h3>
      <div class="campo"><label>Chave</label><input id="pk" value="${esc(pix.chave||"")}" placeholder="CPF, telefone, e-mail ou aleatória"></div>
      <div class="campo"><label>Titular</label><input id="pt" value="${esc(pix.titular||"")}"></div>
      <div class="campo"><label>Banco</label><input id="pb" value="${esc(pix.banco||"")}"></div>
      <div class="campo"><label>Mensagem enviada ao cliente</label>
        <textarea id="pm">${esc(pix.mensagem||"")}</textarea>
        <p class="sub" style="margin-top:5px">Use {chave} e {titular} — são substituídos automaticamente.</p></div>
      <button class="btn btn-pri" id="sp">Salvar</button></div>
  </div>`;
  $("#sl").onclick=async()=>{
    loja={nome:$("#cn").value,telefone:$("#ct").value,endereco:$("#ce").value};
    await sb.from("config").update({valor:loja}).eq("chave","loja");
    $("#logoNome").textContent=loja.nome;toast("Salvo")};
  $("#sp").onclick=async()=>{
    pix={chave:$("#pk").value.trim(),titular:$("#pt").value,banco:$("#pb").value,mensagem:$("#pm").value};
    await sb.from("config").update({valor:pix}).eq("chave","pix");toast("Salvo")};
}
function baixar(n,c){const a=document.createElement("a");
  a.href=URL.createObjectURL(new Blob([c],{type:"text/csv"}));a.download=n;a.click();
  setTimeout(()=>URL.revokeObjectURL(a.href),1500)}
