/* precificacao.js — Calculadora de preco
   Projeto: Sistema PDV/ERP Lanchonete */

/* ============ precificação ============ */
function renderPrecificacao(){
  const fixo=despesas.filter(d=>d.fixa).reduce((s,d)=>s+ +d.valor,0);
  $("#precificacao").innerHTML=`<h2>Precificação</h2>
  <p class="sub">Calcule o preço que cobre custo, taxas, impostos e ainda entrega a margem que você quer.</p>
  <div class="dois">
    <div class="bloco"><h3>Calculadora</h3>
      <div class="campo"><label>Custo dos insumos do item</label><input id="pc" type="number" step="0.01" placeholder="0,00"></div>
      <div class="campo"><label>Rateio de despesa fixa (% da receita)</label><input id="pd" type="number" step="0.1" value="12"></div>
      <div class="campo"><label>Impostos (%)</label><input id="pi" type="number" step="0.1" value="6"></div>
      <div class="campo"><label>Taxa de cartão e delivery (%)</label><input id="pt2" type="number" step="0.1" value="6.5"></div>
      <div class="campo"><label>Margem de lucro desejada (%)</label><input id="pm2" type="number" step="0.1" value="15"></div>
      <div class="faixa" style="margin:0"><span>Preço mínimo de venda</span><b class="num" id="pr">R$ 0,00</b></div>
      <p class="sub" id="pinfo" style="margin-top:10px"></p></div>
    <div class="bloco"><h3>Análise do cardápio atual</h3>
      <p class="sub" style="margin-bottom:10px">Custo fixo mensal cadastrado: <b>${money(fixo)}</b></p>
      <div class="tabela" style="box-shadow:none"><table><thead><tr><th>Item</th><th style="width:90px">Preço</th>
        <th style="width:90px">Custo</th><th style="width:80px">CMV</th><th style="width:80px">Markup</th></tr></thead><tbody>
        ${produtos.map(p=>{const c=custos[p.id]||0,cmv=p.preco>0?c/p.preco*100:0;
          return `<tr><td>${esc(p.nome)}</td><td class="num">${money(p.preco)}</td><td class="num">${money(c)}</td>
          <td class="num" style="color:${cmv>40?"var(--red)":cmv>0?"var(--green)":"inherit"}">${cmv?cmv.toFixed(0)+"%":"—"}</td>
          <td class="num">${c>0?(p.preco/c).toFixed(2)+"x":"—"}</td></tr>`}).join("")}
      </tbody></table></div></div>
  </div>`;
  const calc=()=>{const c=+$("#pc").value||0;
    const pct=((+$("#pd").value||0)+(+$("#pi").value||0)+(+$("#pt2").value||0)+(+$("#pm2").value||0))/100;
    if(pct>=1){$("#pr").textContent="—";$("#pinfo").textContent="A soma dos percentuais passou de 100%. Reduza algum.";return}
    const preco=c/(1-pct);
    $("#pr").textContent=money(preco);
    $("#pinfo").textContent=c?`CMV de ${(c/preco*100).toFixed(1)}% · markup de ${(preco/c).toFixed(2)}x · lucro de ${money(preco*((+$("#pm2").value||0)/100))} por unidade.`:"";};
  ["#pc","#pd","#pi","#pt2","#pm2"].forEach(s=>$(s).oninput=calc);calc();
}
