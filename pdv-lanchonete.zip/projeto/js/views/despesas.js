/* despesas.js — Contas a pagar e custo fixo
   Projeto: Sistema PDV/ERP Lanchonete */

/* ============ contas a pagar ============ */
function renderDespesas(){
  const abertas=despesas.filter(d=>!d.pago),pagas=despesas.filter(d=>d.pago);
  const venc=abertas.filter(d=>d.vencimento&&d.vencimento<hoje());
  $("#despesas").innerHTML=`<h2>Contas a pagar</h2>
  <p class="sub">Marque como fixa o que se repete todo mês: aluguel, energia, gás, contador.</p>
  <div class="kpis">
    <div class="kpi dest"><div class="lb">Em aberto</div><div class="vl num">${money(abertas.reduce((s,d)=>s+ +d.valor,0))}</div></div>
    <div class="kpi"><div class="lb">Vencidas</div><div class="vl num" style="color:${venc.length?"var(--red)":"inherit"}">${venc.length}</div></div>
    <div class="kpi"><div class="lb">Custo fixo mensal</div><div class="vl num">${money(despesas.filter(d=>d.fixa).reduce((s,d)=>s+ +d.valor,0))}</div></div>
    <div class="kpi"><div class="lb">Pagas</div><div class="vl num">${money(pagas.reduce((s,d)=>s+ +d.valor,0))}</div></div>
  </div>
  <div class="toolbar"><button class="btn btn-pri sm" id="ad">Adicionar conta</button></div>
  <div class="tabela"><table><thead><tr><th style="width:28%">Descrição</th><th>Categoria</th>
    <th style="width:120px">Valor</th><th style="width:140px">Vencimento</th><th style="width:70px">Fixa</th>
    <th style="width:70px">Paga</th><th style="width:100px">Situação</th><th style="width:90px"></th></tr></thead><tbody>
    ${despesas.length?despesas.map(d=>{
      const atras=!d.pago&&d.vencimento&&d.vencimento<hoje();
      return `<tr data-id="${d.id}">
      <td><input data-f="descricao" value="${esc(d.descricao)}"></td>
      <td><input data-f="categoria" value="${esc(d.categoria)}"></td>
      <td><input data-f="valor" type="number" step="0.01" value="${+d.valor}"></td>
      <td><input data-f="vencimento" type="date" value="${d.vencimento||""}"></td>
      <td><input type="checkbox" data-f="fixa" ${d.fixa?"checked":""} style="width:auto"></td>
      <td><input type="checkbox" data-f="pago" ${d.pago?"checked":""} style="width:auto"></td>
      <td><span class="badge ${d.pago?"b-ok":atras?"b-red":"b-navy"}">${d.pago?"Paga":atras?"Vencida":"Em aberto"}</span></td>
      <td><button class="btn btn-del sm" data-dd="${d.id}">Excluir</button></td></tr>`}).join("")
      :`<tr><td colspan="8" class="sub" style="padding:26px;text-align:center">Nenhuma conta cadastrada.</td></tr>`}
  </tbody></table></div>`;
  $("#ad").onclick=async()=>{await sb.from("despesas").insert({descricao:"Nova conta",valor:0,vencimento:hoje()});
    await carregar("despesas","vencimento");renderDespesas()};
  $$("#despesas input").forEach(el=>{
    el.onchange=async()=>{
      const id=el.closest("tr").dataset.id,f=el.dataset.f;
      const v=el.type==="checkbox"?el.checked:(f==="valor"?(+el.value||0):(el.value||null));
      const extra=(f==="pago"&&v)?{pago_em:hoje()}:{};
      await sb.from("despesas").update({[f]:v,...extra}).eq("id",id);
      await carregar("despesas","vencimento");renderDespesas()}});
  $$("[data-dd]").forEach(b=>b.onclick=async()=>{if(!confirm("Excluir?"))return;
    await sb.from("despesas").delete().eq("id",b.dataset.dd);await carregar("despesas","vencimento");renderDespesas()});
}
