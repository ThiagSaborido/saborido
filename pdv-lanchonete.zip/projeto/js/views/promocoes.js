/* promocoes.js — Promocoes
   Projeto: Sistema PDV/ERP Lanchonete */

/* ============ promoções ============ */
function renderPromocoes(){
  const hj=hoje();
  const ativas=promocoes.filter(p=>p.ativa&&(!p.fim||p.fim>=hj));
  $("#promocoes").innerHTML=`<h2>Promoções</h2>
  <p class="sub">Cadastre a promoção e vincule a um modelo de mensagem. O disparo acontece na aba Automações WhatsApp.</p>
  <div class="kpis">
    <div class="kpi dest"><div class="lb">Promoções ativas</div><div class="vl num">${ativas.length}</div></div>
    <div class="kpi"><div class="lb">Cadastradas</div><div class="vl num">${promocoes.length}</div></div>
  </div>
  <div class="toolbar"><button class="btn btn-pri sm" id="apr">Nova promoção</button></div>
  <div class="tabela"><table><thead><tr><th style="width:20%">Nome</th><th>Descrição</th>
    <th style="width:120px">Tipo</th><th style="width:100px">Valor</th><th style="width:140px">Início</th>
    <th style="width:140px">Fim</th><th style="width:170px">Modelo de mensagem</th><th style="width:70px">Ativa</th>
    <th style="width:170px"></th></tr></thead><tbody>
    ${promocoes.length?promocoes.map(p=>`<tr data-id="${p.id}">
      <td><input data-f="nome" value="${esc(p.nome)}"></td>
      <td><input data-f="descricao" value="${esc(p.descricao||"")}"></td>
      <td><select data-f="tipo_desconto"><option value="percentual" ${p.tipo_desconto==="percentual"?"selected":""}>Percentual</option>
        <option value="valor" ${p.tipo_desconto==="valor"?"selected":""}>Valor fixo</option></select></td>
      <td><input data-f="valor" type="number" step="0.01" value="${+p.valor}"></td>
      <td><input data-f="inicio" type="date" value="${p.inicio||""}"></td>
      <td><input data-f="fim" type="date" value="${p.fim||""}"></td>
      <td><select data-f="template_id"><option value="">— nenhum —</option>
        ${templates.map(t=>`<option value="${t.id}" ${p.template_id===t.id?"selected":""}>${esc(t.nome)}</option>`).join("")}</select></td>
      <td><input type="checkbox" data-f="ativa" ${p.ativa?"checked":""}></td>
      <td><button class="btn btn-go sm" data-disp="${p.id}">Disparar</button>
          <button class="btn btn-del sm" data-dpr="${p.id}">Excluir</button></td></tr>`).join("")
      :`<tr><td colspan="9" class="sub" style="padding:30px;text-align:center">Nenhuma promoção cadastrada.</td></tr>`}
  </tbody></table></div>`;
  $("#apr").onclick=async()=>{await sb.from("promocoes").insert({nome:"Nova promoção",inicio:hoje()});
    await carregar("promocoes","nome");renderPromocoes()};
  $$("#promocoes input[data-f],#promocoes select[data-f]").forEach(el=>el.onchange=async()=>{
    const id=el.closest("tr").dataset.id,f=el.dataset.f;
    const v=el.type==="checkbox"?el.checked:(f==="valor"?(+el.value||0):(el.value||null));
    await salvarCampo("promocoes",id,f,v);await carregar("promocoes","nome");renderPromocoes()});
  $$("[data-dpr]").forEach(b=>b.onclick=async()=>{if(!confirm("Excluir?"))return;
    await sb.from("promocoes").delete().eq("id",b.dataset.dpr);await carregar("promocoes","nome");renderPromocoes()});
  $$("[data-disp]").forEach(b=>b.onclick=async()=>{
    const p=promocoes.find(x=>x.id===b.dataset.disp);
    if(!p.template_id){toast("Vincule um modelo de mensagem primeiro");return}
    await carregarClientes();await ir("whatsapp");
    setTimeout(()=>{const s=$("#selTpl");if(s){s.value=p.template_id;s.dispatchEvent(new Event("change"))}
      const i=$("#varPromo");if(i)i.value=p.nome+(p.descricao?" — "+p.descricao:"")},250)});
}
