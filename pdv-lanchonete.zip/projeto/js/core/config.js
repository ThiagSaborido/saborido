/* config.js — Endereco do banco e constantes
   Projeto: Sistema PDV/ERP Lanchonete */

/* ============ CONFIG ============ */
const URL_SB="https://dqdyysewplujpfwnbpvg.supabase.co";
const KEY_SB="sb_publishable_NdypLUafOccLuAzPmcL1Xg_14MgTkhU";
const DOMINIO="@lanchonete.local";
const sb=supabase.createClient(URL_SB,KEY_SB);
