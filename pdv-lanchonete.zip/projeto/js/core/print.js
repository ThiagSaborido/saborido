/* print.js — Cupons de 80mm
   Projeto: Sistema PDV/ERP Lanchonete */

/* ============ impressão ============ */
function imprimir(h){$("#print-area").innerHTML=h;window.print()}
function comandaCozinha(p){return `<div class="c big">PEDIDO ${String(p.numero).padStart(3,"0")}</div>
<div class="c b" style="font-size:16px">${esc(p.cliente_nome)}</div>
<div class="c">${esc(p.tipo)} &middot; ${hora(p.criado_em)}</div><div class="hr"></div>
<table>${p.itens.map(i=>`<tr><td class="b" style="width:22px">${i.qtd}x</td><td class="b">${esc(i.nome)}</td></tr>
${i.obs?`<tr><td></td><td>** ${esc(i.obs)} **</td></tr>`:""}`).join("")}</table>
<div class="hr"></div><div class="c">--- COZINHA ---</div><div style="height:12px"></div>`}
function comprovante(p){const sub=p.total+p.desconto;
 return `<div class="c b">${esc(loja.nome)}</div>
${loja.telefone?`<div class="c">${esc(loja.telefone)}</div>`:""}
<div class="c">COMPROVANTE DE VENDA</div>
<div class="c">Pedido ${String(p.numero).padStart(3,"0")} &middot; ${new Date(p.criado_em).toLocaleDateString("pt-BR")} ${hora(p.criado_em)}</div>
<div class="hr"></div><div>Cliente: ${esc(p.cliente_nome)}</div><div>Tipo: ${esc(p.tipo)}</div>
<div class="hr"></div>
<table>${p.itens.map(i=>`<tr><td style="width:20px">${i.qtd}</td><td>${esc(i.nome)}</td><td class="r">${money(i.preco*i.qtd)}</td></tr>
${i.obs?`<tr><td></td><td colspan="2">obs: ${esc(i.obs)}</td></tr>`:""}`).join("")}</table>
<div class="hr"></div><table>
<tr><td>Subtotal</td><td class="r">${money(sub)}</td></tr>
${p.desconto>0?`<tr><td>Desconto</td><td class="r">- ${money(p.desconto)}</td></tr>`:""}
<tr><td class="b">TOTAL</td><td class="r b" style="font-size:15px">${money(p.total)}</td></tr>
<tr><td>${esc(p.forma_pagamento)}</td><td class="r">${money(p.recebido)}</td></tr>
${p.troco>0?`<tr><td>Troco</td><td class="r">${money(p.troco)}</td></tr>`:""}</table>
<div class="hr"></div><div class="c">Obrigado pela preferência!</div>
<div class="c">Documento sem valor fiscal</div><div style="height:14px"></div>`}
