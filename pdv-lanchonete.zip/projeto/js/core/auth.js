/* auth.js — Login, sessao e troca de senha
   Projeto: Sistema PDV/ERP Lanchonete */

/* ============ login ============ */
$("#btnEntrar").onclick=entrar;
$("#lgSenha").onkeydown=e=>{if(e.key==="Enter")entrar()};
async function entrar(){
  $("#lgErro").textContent="";
  const u=$("#lgUser").value.trim().toLowerCase(),s=$("#lgSenha").value;
  if(!u||!s){$("#lgErro").textContent="Preencha usuário e senha.";return}
  const {error}=await sb.auth.signInWithPassword({email:u+DOMINIO,password:s});
  if(error){$("#lgErro").textContent="Usuário ou senha incorretos.";return}
  iniciar();
}
$("#btnSair").onclick=async()=>{await sb.auth.signOut();location.reload()};
$("#btnSenha").onclick=()=>{
  $("#modalRoot").innerHTML=`<div class="overlay"><div class="modal"><h3>Trocar senha</h3>
    <div class="campo"><label>Nova senha (mínimo 6 caracteres)</label><input id="np" type="password"></div>
    <div class="mfoot"><button class="btn btn-out" id="c1" style="flex:1">Cancelar</button>
    <button class="btn btn-go" id="s1" style="flex:1">Salvar</button></div></div></div>`;
  $("#c1").onclick=fecharModal;
  $("#s1").onclick=async()=>{
    const v=$("#np").value;
    if(v.length<6){toast("Senha muito curta");return}
    const {error}=await sb.auth.updateUser({password:v});
    toast(error?"Não foi possível trocar":"Senha alterada");fecharModal()};
};
sb.auth.getSession().then(({data})=>{if(data.session)iniciar()});

async function iniciar(){
  const {data:{user}}=await sb.auth.getUser();
  const {data:p}=await sb.from("perfis").select("*").eq("id",user.id).maybeSingle();
  perfil=p||{nome:"—",papel:"operador"};
  $("#login").style.display="none";$("#app").classList.add("on");
  $("#euNome").textContent=perfil.nome;
  $("#euPapel").textContent=adm()?"Administrador":"Atendente";
  $("#logoPapel").textContent=adm()?"Administração":"Atendimento";
  menu();await base();await verCaixa();
  cats();grid();comanda();rt();sincronizar();$("#busca").focus();
}
