/* nav.js — Monta o menu, a barra inferior e troca de tela
   Projeto: Sistema PDV/ERP Lanchonete */

function menu(){
  const it=[["g","Operação"],["vendas"],["fila"],["caixa"],["g","Atalhos"],["pix"],["troco"],["insumos"],["cardapio"],["fidelidade"],
    ...(adm()?[["g","Financeiro"],["financeiro"],["despesas"],["precificacao"],["maquininhas"],
               ["g","Relacionamento"],["promocoes"],["whatsapp"],
               ["g","Cadastros"],["clientes"],["produtos"],["fornecedores"],["equipe"],["investimentos"],
               ["g","Sistema"],["fiscal"],["config"]]:[])];
  $("#menu").innerHTML=it.map(i=>i[0]==="g"?`<div class="grupo">${i[1]}</div>`
    :`<button data-p="${i[0]}" class="${i[0]==="vendas"?"on":""}">
       <svg class="ic"><use href="#i-${i[0]}"/></svg><span>${PAG[i[0]][0]}</span>
       ${i[0]==="fila"?'<span class="pill" id="pillFila" style="display:none"></span>':""}</button>`).join("");
  $$("#menu button").forEach(b=>b.onclick=()=>ir(b.dataset.p));
  const rapido=["vendas","fila","caixa","pix","troco"];
  $("#bottomnav").innerHTML=rapido.map(k=>`<button data-p="${k}" class="${k==="vendas"?"on":""}">
    <svg class="ic"><use href="#i-${k}"/></svg>${PAG[k][0].split(" ")[0]}</button>`).join("");
  $$("#bottomnav button").forEach(b=>b.onclick=()=>ir(b.dataset.p));
}
async function ir(p){
  if(PAG[p][1]&&!adm())return;
  $$("#menu button").forEach(x=>x.classList.toggle("on",x.dataset.p===p));
  $$("#bottomnav button").forEach(x=>x.classList.toggle("on",x.dataset.p===p));
  $$("main").forEach(m=>m.classList.remove("on"));
  $("#v-"+p).classList.add("on");$("#tituloPagina").textContent=PAG[p][0];
  $("#side").classList.remove("aberto");
  if(p==="fila"){await carregarFila();renderFila()}
  if(p==="caixa"){await verCaixa();renderCaixa()}
  if(p==="pix")renderPix();
  if(p==="troco")renderTroco();
  if(p==="clientes"){await carregarClientes();renderClientes()}
  if(p==="produtos"){await carregarCustos();renderProdutos()}
  if(p==="config")renderConfig();
  if(p==="financeiro")renderFinanceiro();
  if(p==="despesas"){await carregar("despesas","vencimento");renderDespesas()}
  if(p==="insumos"){await carregar("insumos","nome");await carregar("fornecedores","nome");renderInsumos()}
  if(p==="fornecedores"){await carregar("fornecedores","nome");renderFornecedores()}
  if(p==="precificacao"){await carregarCustos();renderPrecificacao()}
  if(p==="maquininhas"){await carregar("maquininhas","nome");renderMaquininhas()}
  if(p==="equipe"){await carregar("funcionarios","nome");await carregar("escalas","dia_semana");renderEquipe()}
  if(p==="investimentos"){await carregar("investimentos","ordem");renderInvest()}
  if(p==="fidelidade"){await carregarFidelidade();renderFidelidade()}
  if(p==="cardapio"){await carregarClientes();renderCardapio()}
  if(p==="promocoes"){await carregar("promocoes","nome");await carregar("wa_templates","nome");renderPromocoes()}
  if(p==="whatsapp"){await carregar("wa_templates","nome");await carregarClientes();renderWhatsapp()}
  if(p==="fiscal"){await carregar("documentos_fiscais","criado_em");renderFiscal()}
  if(p==="vendas")$("#busca").focus();
}
$("#burger").onclick=()=>$("#side").classList.toggle("aberto");
