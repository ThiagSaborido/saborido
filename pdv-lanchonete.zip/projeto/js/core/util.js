/* util.js — Atalhos, formatacao e armazenamento local
   Projeto: Sistema PDV/ERP Lanchonete */

/* ============ UTIL ============ */
const mem={};
const LS={get(k,d){try{const v=localStorage.getItem(k);return v?JSON.parse(v):(k in mem?mem[k]:d)}catch(e){return (k in mem)?mem[k]:d}},
 set(k,v){mem[k]=v;try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}};
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const money=v=>"R$ "+(Number(v)||0).toFixed(2).replace(".",",");
const esc=s=>String(s??"").replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const hoje=()=>new Date().toLocaleDateString("sv-SE",{timeZone:"America/Sao_Paulo"});
const dig=s=>String(s||"").replace(/\D/g,"");
const hora=d=>new Date(d).toLocaleTimeString("pt-BR",{hour:"2-digit",minute:"2-digit"});
function toast(m){const t=document.createElement("div");t.className="toast";t.textContent=m;document.body.appendChild(t);setTimeout(()=>t.remove(),2400)}
