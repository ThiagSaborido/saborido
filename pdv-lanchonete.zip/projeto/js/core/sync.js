/* sync.js — Fila offline e sincronizacao
   Projeto: Sistema PDV/ERP Lanchonete */

/* ============ sync ============ */
function sinal(){const t=$("#tagSync");t.className="chip";
  if(!navigator.onLine){t.classList.add("off");$("#syncTxt").textContent="Sem internet"}
  else if(pend.length){t.classList.add("pend");$("#syncTxt").textContent=pend.length+" a enviar"}
  else $("#syncTxt").textContent="Sincronizado"}
addEventListener("online",()=>{sinal();sincronizar()});addEventListener("offline",sinal);
setInterval(()=>{if(navigator.onLine&&pend.length)sincronizar()},20000);
async function sincronizar(){
  sinal();if(!navigator.onLine||!pend.length)return;
  for(const p of [...pend]){
    const {error}=await sb.rpc("registrar_pedido",{p});
    if(error){console.error(error);break}
    pend=pend.filter(x=>x.uid!==p.uid);LS.set("s.pend",pend)}
  sinal();await carregarFila();
  if($("#v-fila").classList.contains("on"))renderFila();
}
