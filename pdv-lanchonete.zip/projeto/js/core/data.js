/* data.js — Carga de dados e tempo real
   Projeto: Sistema PDV/ERP Lanchonete */

/* ============ carga ============ */
async function base(){
  const {data:c}=await sb.from("config").select("*");
  (c||[]).forEach(x=>{if(x.chave==="loja")loja=x.valor;if(x.chave==="pix")pix=x.valor});
  $("#logoNome").textContent=loja.nome||"Lanchonete";
  const {data:pr}=await sb.from("produtos").select("*").eq("ativo",true).order("ordem");
  if(pr){produtos=pr;LS.set("s.produtos",produtos)}
  await carregarFila();await carregarClientes();
}
async function carregarCustos(){if(!adm())return;
  const {data}=await sb.from("produto_custos").select("*");
  custos={};(data||[]).forEach(c=>custos[c.produto_id]=+c.custo)}
async function carregarFila(){
  const {data}=await sb.from("vw_fila").select("*").eq("data",hoje()).order("numero",{ascending:false});
  filaView=data||[];pill()}
async function carregarClientes(){
  const {data}=await sb.from("clientes").select("*").order("nome");
  clientes=data||[]}
async function verCaixa(){
  const {data}=await sb.from("caixas").select("*").eq("status","aberto").order("aberto_em",{ascending:false}).limit(1);
  caixa=(data&&data[0])||null;
  const t=$("#tagCaixa");
  if(caixa){t.className="chip";t.innerHTML=`<i></i>Caixa aberto · ${hora(caixa.aberto_em)}`}
  else{t.className="chip fechado";t.innerHTML="<i></i>Caixa fechado"}
}
function rt(){
  sb.channel("live").on("postgres_changes",{event:"*",schema:"public",table:"pedidos"},async()=>{
    await carregarFila();if($("#v-fila").classList.contains("on"))renderFila();
  }).subscribe();
}

/* ============ carregador genérico ============ */
const DEST={despesas:v=>despesas=v,insumos:v=>insumos=v,fornecedores:v=>fornecedores=v,
 maquininhas:v=>maquininhas=v,funcionarios:v=>funcionarios=v,escalas:v=>escalas=v,investimentos:v=>invest=v,
 promocoes:v=>promocoes=v,wa_templates:v=>templates=v,documentos_fiscais:v=>docs=v,fidelidade_regras:v=>regras=v};
async function carregar(tab,ord){
  const {data,error}=await sb.from(tab).select("*").order(ord);
  if(!error)DEST[tab](data||[]);
}
async function salvarCampo(tab,id,campo,valor){await sb.from(tab).update({[campo]:valor}).eq("id",id)}
function editar(el,tab,numericos=[]){
  el.onchange=async()=>{
    const id=el.closest("tr").dataset.id,f=el.dataset.f;
    const v=el.type==="checkbox"?el.checked:(numericos.includes(f)?(+el.value||0):(el.value||null));
    await salvarCampo(tab,id,f,v);toast("Salvo")};
}
const hojeISO=()=>hoje();
function intervalo(){
  const d=new Date(),ini=new Date();
  if(periodo==="hoje")return [hoje(),hoje()];
  if(periodo==="mes"){ini.setDate(1);return [ini.toLocaleDateString("sv-SE"),hoje()]}
  if(periodo==="passado"){const a=new Date(d.getFullYear(),d.getMonth()-1,1),b=new Date(d.getFullYear(),d.getMonth(),0);
    return [a.toLocaleDateString("sv-SE"),b.toLocaleDateString("sv-SE")]}
  ini.setDate(d.getDate()-29);return [ini.toLocaleDateString("sv-SE"),hoje()];
}
