/* state.js — Estado compartilhado da aplicacao
   Projeto: Sistema PDV/ERP Lanchonete */

/* ============ STATE ============ */
let perfil=null,produtos=LS.get("s.produtos",[]),custos={},clientes=[],filaView=[];
let caixa=null,loja={nome:"Lanchonete"},pix={chave:"",titular:"",mensagem:""};
let pend=LS.get("s.pend",[]),carrinho=[],tipoAtual="Balcao",catAtual="Todos",clienteSel=null;
const adm=()=>perfil?.papel==="admin";
const PAG={vendas:["Vendas",0],fila:["Fila de pedidos",0],caixa:["Caixa",0],pix:["Chave PIX",0],
 troco:["Calculadora de troco",0],insumos:["Estoque de insumos",0],
 financeiro:["Financeiro",1],despesas:["Contas a pagar",1],fornecedores:["Fornecedores",1],
 precificacao:["Precificação",1],maquininhas:["Maquininhas e taxas",1],equipe:["Equipe e escala",1],
 investimentos:["Investimentos",1],clientes:["Clientes",1],produtos:["Cardápio",1],config:["Configurações",1],
 fidelidade:["Cartão fidelidade",0],cardapio:["Enviar cardápio",0],
 promocoes:["Promoções",1],whatsapp:["Automações WhatsApp",1],fiscal:["Documentos fiscais",1]};
let insumos=[],fornecedores=[],despesas=[],maquininhas=[],funcionarios=[],escalas=[],invest=[];
let periodo="hoje";
